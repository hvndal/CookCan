package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.bounceClick
import com.example.ui.theme.pulsate
import com.example.ui.theme.ConfettiEffect

import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.PantryItem
import com.example.ui.AppViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.InputStream
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

// Suspend helper to retrieve CameraX process provider asynchronously
suspend fun android.content.Context.getCameraProvider(): ProcessCameraProvider = suspendCoroutine { continuation ->
    val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
    cameraProviderFuture.addListener({
        try {
            continuation.resume(cameraProviderFuture.get())
        } catch (e: Exception) {
            continuation.resumeWith(Result.failure(e))
        }
    }, ContextCompat.getMainExecutor(this))
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun CameraScreen(
    viewModel: AppViewModel,
    onNavigateToRecipes: () -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()
    val isScanning = viewModel.isScanning
    val pantryItems by viewModel.pantryItems.collectAsState()

    var confettiTrigger by remember { mutableStateOf(false) }

    LaunchedEffect(isScanning) {
        if (!isScanning && pantryItems.isNotEmpty()) {
            confettiTrigger = true
        }
    }

    // Camera Access permission state
    val cameraPermissionState = rememberPermissionState(android.Manifest.permission.CAMERA)
    var forceSimulatedCamera by remember { mutableStateOf(false) }

    // Manual Add states
    var showManualAddDialog by remember { mutableStateOf(false) }
    var manualItemName by remember { mutableStateOf("") }
    var manualItemQuantity by remember { mutableStateOf("1") }
    var manualItemUnit by remember { mutableStateOf("pcs") }
    var manualItemCategory by remember { mutableStateOf("Produce") }

    val showCameraPreview = cameraPermissionState.status.isGranted && !forceSimulatedCamera

    // Scanning animation laser line
    val infiniteTransition = rememberInfiniteTransition(label = "laser")
    val laserOffset by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOut),
            repeatMode = RepeatMode.Reverse
        ),
        label = "offset"
    )

    // Image Picker for custom uploads
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                val inputStream: InputStream? = context.contentResolver.openInputStream(it)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                if (bitmap != null) {
                    viewModel.scanIngredients(bitmap)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // CameraX instance variables
    val previewView = remember { PreviewView(context) }
    val imageCapture = remember { ImageCapture.Builder().build() }
    val executor = remember { ContextCompat.getMainExecutor(context) }

    // Bind CameraX preview
    LaunchedEffect(showCameraPreview) {
        if (showCameraPreview) {
            try {
                val cameraProvider = context.getCameraProvider()
                val preview = Preview.Builder().build()
                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    imageCapture
                )
                preview.setSurfaceProvider(previewView.surfaceProvider)
            } catch (e: Exception) {
                Log.e("CameraScreen", "Failed to start CameraX: ${e.message}", e)
                // Auto fallback to Simulated Mode if physical hardware is missing
                forceSimulatedCamera = true
            }
        }
    }

    if (!cameraPermissionState.status.isGranted && !forceSimulatedCamera) {
        // VIEW 1: Material 3 Camera Access Permission Screen
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Camera Access", style = MaterialTheme.typography.headlineMedium) },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            },
            modifier = modifier.fillMaxSize()
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                    shape = CircleShape,
                    modifier = Modifier.size(120.dp),
                    border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Camera Icon",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(56.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                Text(
                    text = "Countertop AI Scanner",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Grant camera access to scan your countertop, automatically identify fresh ingredients, and craft tailored gourmet culinary recipes in seconds!",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    lineHeight = 24.sp
                )

                Spacer(modifier = Modifier.height(48.dp))

                Button(
                    onClick = { cameraPermissionState.launchPermissionRequest() },
                    shape = CircleShape,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Camera, contentDescription = "Grant")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Grant Camera Permission", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(
                    onClick = { imagePickerLauncher.launch("image/*") },
                    shape = CircleShape,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = "Upload")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Upload Fridge Photo from Gallery", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(
                    onClick = { forceSimulatedCamera = true },
                    shape = CircleShape,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "Simulate")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Use Simulated Camera", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }
    } else {
        // VIEW 2: Camera Viewfinder View
        Box(modifier = modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Viewfinder Area (Half of screen)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.2f)
                        .background(Color.Black)
                ) {
                    if (showCameraPreview) {
                        // Live CameraX Preview
                        AndroidView(
                            factory = { previewView },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        // High-End Gourmet Simulated Viewfinder
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data("https://lh3.googleusercontent.com/aida-public/AB6AXuDJUgBbYhhzF9Y2kYC4otxdknLnp6rcvgm9yu4FFRN_DrGcF7JRJ0tsshdlhf0I7d5IR_4pjJMbbsX439yXyYSDj3IzogiNMx6PepNsEsQqP3Y5B97SCTWA3DHqdfcXBnZuFC9uzmwYGGwk6jNSrXTqGynyk1Wun3KE6UR7VUiIcinVoLQFbdCI8PGSP8W6cbA2FLCecHtX0YjHaA-PVCLVy-HSfyJahaxP_x0yQlazG9QSP2jKS5hN")
                                .crossfade(true)
                                .build(),
                            contentDescription = "Simulated Viewfinder",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                            alpha = 0.8f
                        )
                    }

                    // Real-time confidence dot overlays
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxSize()
                    ) {
                        val containerWidth = maxWidth
                        val containerHeight = maxHeight

                        // Percentage coordinates for consistent alignment of items in the viewfinder area
                        val overlayPositions = listOf(
                            Pair(0.12f, 0.22f), // Item 1 position
                            Pair(0.55f, 0.38f), // Item 2 position
                            Pair(0.18f, 0.58f), // Item 3 position
                            Pair(0.50f, 0.52f), // Item 4 position
                            Pair(0.32f, 0.35f), // Item 5 position
                            Pair(0.62f, 0.68f), // Item 6 position
                            Pair(0.38f, 0.72f)  // Item 7 position
                        )

                        if (pantryItems.isEmpty()) {
                            // Show beautiful preview guides to simulate live target tracking
                            val guides = listOf(
                                Triple("Heirloom Tomato", 0.95, Pair(0.15f, 0.35f)),
                                Triple("Fresh Garlic", 0.91, Pair(0.58f, 0.48f))
                            )
                            guides.forEach { (name, conf, pos) ->
                                val x = containerWidth * pos.first
                                val y = containerHeight * pos.second
                                ConfidenceIndicatorDot(
                                    name = name,
                                    confidence = conf,
                                    isPlaceholder = true,
                                    modifier = Modifier.offset(x = x, y = y)
                                )
                            }
                        } else {
                            // Dynamically map detected ingredients to viewfinder space with confidence levels
                            pantryItems.forEachIndexed { index, item ->
                                val pos = overlayPositions.getOrElse(index) { Pair(0.5f, 0.5f) }
                                val x = containerWidth * pos.first
                                val y = containerHeight * pos.second
                                ConfidenceIndicatorDot(
                                    name = item.name,
                                    confidence = item.confidence,
                                    isPlaceholder = false,
                                    modifier = Modifier.offset(x = x, y = y)
                                )
                            }
                        }
                    }

                    // Laser line animation
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.005f)
                            .align(Alignment.TopCenter)
                            .offset(y = 350.dp * laserOffset)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color.Transparent, MaterialTheme.colorScheme.primary, Color.Transparent)
                                )
                            )
                    )

                    // Floating Exit/Back Button on Viewfinder top-left
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .statusBarsPadding()
                            .padding(16.dp)
                            .background(Color.Black.copy(alpha = 0.4f), CircleShape)
                            .align(Alignment.TopStart)
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Exit Scanner", tint = Color.White)
                    }

                    // Shutter button footer overlaid on bottom of viewfinder
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 24.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                // Fallback/Toggle simulated mode manually if desired
                                forceSimulatedCamera = !forceSimulatedCamera
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.Black.copy(alpha = 0.4f), CircleShape)
                        ) {
                            Icon(
                                imageVector = if (forceSimulatedCamera) Icons.Default.CameraAlt else Icons.Default.AutoAwesome,
                                contentDescription = "Toggle Simulator",
                                tint = Color.White
                            )
                        }

                        // Capture/Shutter button
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .background(Color.White.copy(alpha = 0.2f), CircleShape)
                                .border(4.dp, Color.White, CircleShape)
                                .clip(CircleShape)
                                .run {
                                    if (!isScanning) this.pulsate() else this
                                }
                                .bounceClick {
                                    if (showCameraPreview) {
                                        // Capture live CameraX picture
                                        val tempFile = File(context.cacheDir, "scan_${System.currentTimeMillis()}.jpg")
                                        val outputOptions = ImageCapture.OutputFileOptions.Builder(tempFile).build()

                                        imageCapture.takePicture(
                                            outputOptions,
                                            executor,
                                            object : ImageCapture.OnImageSavedCallback {
                                                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                                    val bitmap = BitmapFactory.decodeFile(tempFile.absolutePath)
                                                    if (bitmap != null) {
                                                        viewModel.scanIngredients(bitmap)
                                                    } else {
                                                        runSimulatedScan(context, viewModel, coroutineScope)
                                                    }
                                                }

                                                override fun onError(exception: ImageCaptureException) {
                                                    Log.e("CameraScreen", "Image capture failed: ${exception.message}")
                                                    runSimulatedScan(context, viewModel, coroutineScope)
                                                }
                                            }
                                        )
                                    } else {
                                        // Execute simulated countertop scan
                                        runSimulatedScan(context, viewModel, coroutineScope)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                            )
                        }

                        IconButton(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.Black.copy(alpha = 0.4f), CircleShape)
                        ) {
                            Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = "Gallery", tint = Color.White)
                        }
                    }
                }

                // Ingredient Drawer (Bottom half)
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .offset(y = (-16).dp),
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState())
                        ) {
                            // Drag handle bar
                            Box(
                                modifier = Modifier
                                    .width(40.dp)
                                    .height(4.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.outlineVariant)
                                    .align(Alignment.CenterHorizontally)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Column {
                                    Text(
                                        text = if (forceSimulatedCamera) "SIMULATED COUNTERTOP" else "LIVE SCANNER",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Countertop Contents",
                                        style = MaterialTheme.typography.headlineMedium
                                    )
                                }
                                Text(
                                    text = "+ Add Manually",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    modifier = Modifier
                                        .clickable { showManualAddDialog = true }
                                        .padding(4.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // --- Manual Search and Add Section ---
                            var manualSearchQuery by remember { mutableStateOf("") }
                            val standardIngredients = remember {
                                listOf(
                                    StandardIngredient("Onion", "Produce", "pcs", "🧅"),
                                    StandardIngredient("Tomato", "Produce", "pcs", "🍅"),
                                    StandardIngredient("Garlic", "Produce", "bulb", "🧄"),
                                    StandardIngredient("Lemon", "Produce", "pcs", "🍋"),
                                    StandardIngredient("Avocado", "Produce", "pcs", "🥑"),
                                    StandardIngredient("Chilli", "Produce", "pcs", "🌶️"),
                                    StandardIngredient("Chicken Breast", "Meat", "lbs", "🍗"),
                                    StandardIngredient("Beef Steak", "Meat", "lbs", "🥩"),
                                    StandardIngredient("Egg", "Dairy", "pcs", "🥚"),
                                    StandardIngredient("Milk", "Dairy", "carton", "🥛"),
                                    StandardIngredient("Butter", "Dairy", "pack", "🧈"),
                                    StandardIngredient("Cheese", "Dairy", "g", "🧀"),
                                    StandardIngredient("Ginger", "Produce", "pcs", "🫚"),
                                    StandardIngredient("Cilantro", "Produce", "bunch", "🌿"),
                                    StandardIngredient("Bell Pepper", "Produce", "pcs", "🫑"),
                                    StandardIngredient("Broccoli", "Produce", "head", "🥦"),
                                    StandardIngredient("Carrot", "Produce", "pcs", "🥕"),
                                    StandardIngredient("Potato", "Produce", "pcs", "🥔"),
                                    StandardIngredient("Mushroom", "Produce", "pack", "🍄"),
                                    StandardIngredient("Spinach", "Produce", "bag", "🥬"),
                                    StandardIngredient("Rosemary", "Spices", "sprigs", "🌿"),
                                    StandardIngredient("Olive Oil", "Pantry", "bottle", "🧴"),
                                    StandardIngredient("Black Pepper", "Spices", "g", "🧂"),
                                    StandardIngredient("Salt", "Spices", "g", "🧂"),
                                    StandardIngredient("Rice", "Pantry", "g", "🍚"),
                                    StandardIngredient("Pasta", "Pantry", "g", "🍝")
                                )
                            }

                            val filteredSuggestions = remember(manualSearchQuery, pantryItems) {
                                if (manualSearchQuery.isBlank()) {
                                    // Show popular standard items that are not already in pantry
                                    standardIngredients.filter { std ->
                                        pantryItems.none { it.name.equals(std.name, ignoreCase = true) }
                                    }.take(6)
                                } else {
                                    standardIngredients.filter { std ->
                                        std.name.contains(manualSearchQuery, ignoreCase = true) &&
                                        pantryItems.none { it.name.equals(std.name, ignoreCase = true) }
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = manualSearchQuery,
                                onValueChange = { manualSearchQuery = it },
                                placeholder = { Text("Search & add ingredients quickly...", style = MaterialTheme.typography.bodyMedium) },
                                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.primary) },
                                trailingIcon = {
                                    if (manualSearchQuery.isNotEmpty()) {
                                        IconButton(onClick = { manualSearchQuery = "" }) {
                                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.05f),
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                                )
                            )

                            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                Text(
                                    text = if (manualSearchQuery.isBlank()) "POPULAR QUICK ADD" else "SEARCH RESULTS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                                ) {
                                    // Custom addition option if search query doesn't perfectly match suggestions
                                    if (manualSearchQuery.isNotBlank() && filteredSuggestions.none { it.name.equals(manualSearchQuery, ignoreCase = true) }) {
                                        item {
                                            Surface(
                                                shape = CircleShape,
                                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                                                modifier = Modifier.clickable {
                                                    viewModel.addPantryItem(
                                                        name = manualSearchQuery.trim(),
                                                        quantity = 1.0,
                                                        unit = "pcs",
                                                        category = "Produce"
                                                    )
                                                    manualSearchQuery = ""
                                                }
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                                ) {
                                                    Text(text = "🥣", fontSize = 14.sp)
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "Add \"${manualSearchQuery.trim()}\"",
                                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    items(filteredSuggestions) { std ->
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                            modifier = Modifier.clickable {
                                                viewModel.addPantryItem(
                                                    name = std.name,
                                                    quantity = if (std.defaultUnit == "pcs") 1.0 else 100.0,
                                                    unit = std.defaultUnit,
                                                    category = std.category
                                                )
                                                manualSearchQuery = ""
                                            }
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                            ) {
                                                Text(text = std.emoji, fontSize = 14.sp)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "+ ${std.name}",
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Scrollable list of scanned elements
                            if (pantryItems.isEmpty()) {
                                Text(
                                    text = "Your kitchen counterpart scan is ready. Tap the shutter button to scan ingredients!",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.padding(vertical = 12.dp)
                                )
                            } else {
                                LazyRow(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(pantryItems) { item ->
                                        Surface(
                                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                            shape = CircleShape,
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f))
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                            ) {
                                                Text(
                                                    text = getIngredientEmoji(item.name),
                                                    fontSize = 14.sp
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = item.name,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "Remove",
                                                    modifier = Modifier
                                                        .size(16.dp)
                                                        .clip(CircleShape)
                                                        .clickable { viewModel.deletePantryItem(item.id) },
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Common culinary additions
                            Text(
                                text = "RECOMMENDED BASICS",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                    modifier = Modifier.clickable {
                                        viewModel.addPantryItem("Olive Oil", 1.0, "bottle", "Pantry")
                                    }
                                ) {
                                    Text(
                                        text = "+ Olive Oil",
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                    )
                                }

                                Surface(
                                    shape = CircleShape,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                    modifier = Modifier.clickable {
                                        viewModel.addPantryItem("Black Pepper", 50.0, "g", "Spices")
                                    }
                                ) {
                                    Text(
                                        text = "+ Black Pepper",
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        // Generate Button
                        Button(
                            onClick = onNavigateToRecipes,
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "Recipes")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Generate Recipes",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }
            }

            // High thinking analyzer HUD
            if (isScanning) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.65f)),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "AI is thinking...",
                                style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Analyzing ingredients on the kitchen countertop...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // Manual Add Dialog
            if (showManualAddDialog) {
                AlertDialog(
                    onDismissRequest = { showManualAddDialog = false },
                    title = {
                        Text(
                            text = "Add Custom Ingredient",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    },
                    text = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = manualItemName,
                                onValueChange = { manualItemName = it },
                                label = { Text("Ingredient Name") },
                                placeholder = { Text("e.g. Avocado, Lemon, Chilli") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = manualItemQuantity,
                                    onValueChange = { manualItemQuantity = it },
                                    label = { Text("Qty") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = manualItemUnit,
                                    onValueChange = { manualItemUnit = it },
                                    label = { Text("Unit") },
                                    placeholder = { Text("pcs/g/ml") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1.2f)
                                )
                            }

                            // Simple Category selection chips
                            Column {
                                Text(
                                    text = "CATEGORY",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    val categoriesList = listOf("Produce", "Meat", "Dairy", "Pantry", "Spices")
                                    items(categoriesList) { cat ->
                                        val isSelected = manualItemCategory == cat
                                        Surface(
                                            onClick = { manualItemCategory = cat },
                                            shape = CircleShape,
                                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                            border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                                        ) {
                                            Text(
                                                text = cat,
                                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                if (manualItemName.isNotBlank()) {
                                    val qtyVal = manualItemQuantity.toDoubleOrNull() ?: 1.0
                                    viewModel.addPantryItem(
                                        name = manualItemName.trim(),
                                        quantity = qtyVal,
                                        unit = manualItemUnit.trim().ifEmpty { "pcs" },
                                        category = manualItemCategory
                                    )
                                    // Clear fields
                                    manualItemName = ""
                                    manualItemQuantity = "1"
                                    manualItemUnit = "pcs"
                                    showManualAddDialog = false
                                }
                            },
                            shape = CircleShape
                        ) {
                            Text("Add to List")
                        }
                    },
                    dismissButton = {
                        TextButton(
                            onClick = { showManualAddDialog = false }
                        ) {
                            Text("Cancel")
                        }
                    }
                )
            }

            ConfettiEffect(
                trigger = confettiTrigger,
                onFinished = { confettiTrigger = false }
            )
        }
    }
}

// Simulated automated scanner routine helper
private fun runSimulatedScan(
    context: android.content.Context,
    viewModel: AppViewModel,
    coroutineScope: kotlinx.coroutines.CoroutineScope
) {
    coroutineScope.launch {
        viewModel.isScanning = true
        val url = "https://lh3.googleusercontent.com/aida-public/AB6AXuDJUgBbYhhzF9Y2kYC4otxdknLnp6rcvgm9yu4FFRN_DrGcF7JRJ0tsshdlhf0I7d5IR_4pjJMbbsX439yXyYSDj3IzogiNMx6PepNsEsQqP3Y5B97SCTWA3DHqdfcXBnZuFC9uzmwYGGwk6jNSrXTqGynyk1Wun3KE6UR7VUiIcinVoLQFbdCI8PGSP8W6cbA2FLCecHtX0YjHaA-PVCLVy-HSfyJahaxP_x0yQlazG9QSP2jKS5hN"
        val bitmap = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val client = okhttp3.OkHttpClient()
                val request = okhttp3.Request.Builder().url(url).build()
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val bytes = response.body?.bytes()
                        if (bytes != null) {
                            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        } else null
                    } else null
                }
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
        if (bitmap != null) {
            viewModel.scanIngredients(bitmap)
        } else {
            // Fallback to simulated data if no network / error
            delay(1500)
            viewModel.addPantryItem("Heirloom Tomato", 3.0, "pcs", "Produce")
            viewModel.addPantryItem("Fresh Garlic", 1.0, "bulb", "Produce")
            viewModel.addPantryItem("Rosemary", 2.0, "sprigs", "Spices")
            viewModel.addPantryItem("Sea Salt", 100.0, "g", "Pantry")
            viewModel.isScanning = false
        }
    }
}

@Composable
fun ConfidenceIndicatorDot(
    name: String,
    confidence: Double,
    isPlaceholder: Boolean,
    modifier: Modifier = Modifier
) {
    // Elegant pulsing animation for the target tracking dot
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 2.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseScale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseAlpha"
    )

    // Select color based on confidence level
    // High: >= 85%, Mid: 60-84%, Low: < 60%
    val indicatorColor = when {
        confidence >= 0.85 -> Color(0xFF4CAF50) // Emerald Green
        confidence >= 0.60 -> Color(0xFFFFC107) // Amber Yellow
        else -> Color(0xFFFF5722) // Deep Orange
    }

    Box(
        modifier = modifier.wrapContentSize(),
        contentAlignment = Alignment.Center
    ) {
        // Outer pulsing ring
        Box(
            modifier = Modifier
                .size(16.dp)
                .graphicsLayer {
                    scaleX = pulseScale
                    scaleY = pulseScale
                    alpha = pulseAlpha
                }
                .background(indicatorColor.copy(alpha = 0.4f), CircleShape)
        )

        // Inner solid core dot
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(indicatorColor, CircleShape)
                .border(1.dp, Color.White, CircleShape)
        )

        // Glassmorphic tag next to/above the dot with info
        Surface(
            color = Color.Black.copy(alpha = 0.65f),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
            modifier = Modifier
                .offset(x = 12.dp, y = (-12).dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Spacer(modifier = Modifier.width(6.dp))
                // Confidence pill
                Surface(
                    color = indicatorColor.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(4.dp),
                    border = BorderStroke(0.5.dp, indicatorColor.copy(alpha = 0.4f)),
                    modifier = Modifier.padding(start = 2.dp)
                ) {
                    Text(
                        text = "${(confidence * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.sp
                        ),
                        color = indicatorColor,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }
        }
    }
}

data class StandardIngredient(
    val name: String,
    val category: String,
    val defaultUnit: String,
    val emoji: String
)

fun getIngredientEmoji(name: String): String {
    val lower = name.lowercase()
    return when {
        lower.contains("tomato") -> "🍅"
        lower.contains("garlic") -> "🧄"
        lower.contains("rosemary") -> "🌿"
        lower.contains("salmon") -> "🐟"
        lower.contains("onion") -> "🧅"
        lower.contains("bell pepper") || lower.contains("pepper") -> "🫑"
        lower.contains("chicken") -> "🍗"
        lower.contains("beef") || lower.contains("steak") -> "🥩"
        lower.contains("egg") -> "🥚"
        lower.contains("milk") -> "🥛"
        lower.contains("butter") -> "🧈"
        lower.contains("cheese") -> "🧀"
        lower.contains("avocado") -> "🥑"
        lower.contains("chilli") || lower.contains("chili") -> "🌶️"
        lower.contains("ginger") -> "🫚"
        lower.contains("lemon") || lower.contains("lime") -> "🍋"
        lower.contains("broccoli") -> "🥦"
        lower.contains("carrot") -> "🥕"
        lower.contains("potato") -> "🥔"
        lower.contains("mushroom") -> "🍄"
        lower.contains("spinach") -> "🥬"
        lower.contains("cilantro") || lower.contains("basil") || lower.contains("herb") || lower.contains("parsley") || lower.contains("thyme") -> "🌿"
        lower.contains("olive oil") || lower.contains("oil") -> "🧴"
        lower.contains("soy sauce") -> "🧴"
        lower.contains("salt") || lower.contains("pepper") || lower.contains("spice") || lower.contains("cumin") || lower.contains("paprika") -> "🧂"
        lower.contains("rice") -> "🍚"
        lower.contains("pasta") -> "🍝"
        lower.contains("flour") -> "🌾"
        lower.contains("shrimp") -> "🍤"
        lower.contains("honey") -> "🍯"
        else -> "🥣"
    }
}
