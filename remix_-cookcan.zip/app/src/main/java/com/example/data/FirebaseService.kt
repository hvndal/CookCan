package com.example.data

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.util.UUID

object FirebaseService {
    private const val TAG = "FirebaseService"
    
    var isRealFirebaseEnabled = false
        private set

    fun initialize(context: Context) {
        if (isRealFirebaseEnabled) return
        
        try {
            // First, see if Firebase is auto-initialized (via google-services.json)
            FirebaseApp.getInstance()
            isRealFirebaseEnabled = true
            Log.d(TAG, "Firebase auto-initialized successfully.")
        } catch (e: Exception) {
            Log.d(TAG, "Firebase auto-initialization not found. Running in Sandbox Mode.")
            isRealFirebaseEnabled = false
        }
    }

    // AUTH ACTIONS
    suspend fun signUpWithEmail(email: String, password: String): AuthResult {
        if (isRealFirebaseEnabled) {
            return try {
                val authResult = FirebaseAuth.getInstance()
                    .createUserWithEmailAndPassword(email, password)
                    .await()
                val user = authResult.user
                if (user != null) {
                    // Create user profile in Firestore
                    saveUserProfile(user.uid, email, "Chef Companion")
                    AuthResult.Success(user.uid, email)
                } else {
                    AuthResult.Error("Failed to register user.")
                }
            } catch (e: Exception) {
                AuthResult.Error(e.localizedMessage ?: "Registration error")
            }
        } else {
            // Simulated Sandbox Auth
            return if (email.contains("@") && password.length >= 6) {
                AuthResult.Success("sandbox_uid_" + UUID.randomUUID().toString().take(6), email)
            } else if (password.length < 6) {
                AuthResult.Error("Password must be at least 6 characters long.")
            } else {
                AuthResult.Error("Please enter a valid email address.")
            }
        }
    }

    suspend fun signInWithEmail(email: String, password: String): AuthResult {
        if (isRealFirebaseEnabled) {
            return try {
                val authResult = FirebaseAuth.getInstance()
                    .signInWithEmailAndPassword(email, password)
                    .await()
                val user = authResult.user
                if (user != null) {
                    AuthResult.Success(user.uid, email)
                } else {
                    AuthResult.Error("Failed to sign in.")
                }
            } catch (e: Exception) {
                AuthResult.Error(e.localizedMessage ?: "Authentication error")
            }
        } else {
            // Simulated Sandbox Auth
            return if (email.contains("@") && password.length >= 6) {
                AuthResult.Success("sandbox_uid_12345", email)
            } else if (password.length < 6) {
                AuthResult.Error("Password must be at least 6 characters long.")
            } else {
                AuthResult.Error("Invalid credentials.")
            }
        }
    }

    suspend fun signInAnonymously(): AuthResult {
        if (isRealFirebaseEnabled) {
            return try {
                val authResult = FirebaseAuth.getInstance().signInAnonymously().await()
                val user = authResult.user
                if (user != null) {
                    AuthResult.Success(user.uid, "guest@cookcan.com")
                } else {
                    AuthResult.Error("Anonymous auth failed.")
                }
            } catch (e: Exception) {
                AuthResult.Error(e.localizedMessage ?: "Guest login error")
            }
        } else {
            return AuthResult.Success("sandbox_uid_guest", "guest@cookcan.com")
        }
    }

    fun signOut() {
        if (isRealFirebaseEnabled) {
            try {
                FirebaseAuth.getInstance().signOut()
            } catch (e: Exception) {
                Log.e(TAG, "Error signing out from Firebase: ${e.message}")
            }
        }
    }

    private suspend fun saveUserProfile(uid: String, email: String, name: String) {
        if (!isRealFirebaseEnabled) return
        try {
            val db = FirebaseFirestore.getInstance()
            val profile = hashMapOf(
                "uid" to uid,
                "email" to email,
                "displayName" to name,
                "createdAt" to System.currentTimeMillis()
            )
            db.collection("users").document(uid).set(profile).await()
        } catch (e: Exception) {
            Log.e(TAG, "Error saving user profile: ${e.message}")
        }
    }

    // CLOUD SYNC LOGIC
    suspend fun syncPantryToCloud(uid: String, items: List<PantryItem>): Boolean {
        if (isRealFirebaseEnabled) {
            return try {
                val db = FirebaseFirestore.getInstance()
                val batch = db.batch()
                val collectionRef = db.collection("users").document(uid).collection("pantry")
                
                // Clear existing cloud items first (simple sync)
                val snapshot = collectionRef.get().await()
                for (doc in snapshot.documents) {
                    batch.delete(doc.reference)
                }
                
                // Upload current local items
                for (item in items) {
                    val data = hashMapOf(
                        "id" to item.id,
                        "name" to item.name,
                        "quantity" to item.quantity,
                        "unit" to item.unit,
                        "category" to item.category,
                        "confidence" to item.confidence,
                        "purchaseDate" to item.purchaseDate,
                        "expirationDate" to item.expirationDate,
                        "freshness" to item.freshness
                    )
                    val docRef = collectionRef.document(if (item.id > 0) item.id.toString() else UUID.randomUUID().toString())
                    batch.set(docRef, data)
                }
                batch.commit().await()
                true
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing pantry to cloud: ${e.message}")
                false
            }
        } else {
            // Simulated backup
            Log.d(TAG, "Sandbox Sync: Pantry items saved successfully for user $uid")
            return true
        }
    }

    suspend fun fetchPantryFromCloud(uid: String): List<PantryItem> {
        if (isRealFirebaseEnabled) {
            return try {
                val db = FirebaseFirestore.getInstance()
                val snapshot = db.collection("users").document(uid).collection("pantry").get().await()
                snapshot.documents.mapNotNull { doc ->
                    try {
                        PantryItem(
                            id = (doc.getLong("id") ?: 0L).toInt(),
                            name = doc.getString("name") ?: "",
                            quantity = doc.getDouble("quantity") ?: 1.0,
                            unit = doc.getString("unit") ?: "pcs",
                            category = doc.getString("category") ?: "Produce",
                            confidence = doc.getDouble("confidence") ?: 1.0,
                            purchaseDate = doc.getLong("purchaseDate") ?: System.currentTimeMillis(),
                            expirationDate = doc.getLong("expirationDate") ?: System.currentTimeMillis(),
                            freshness = doc.getString("freshness") ?: "Fresh"
                        )
                    } catch (e: Exception) {
                        null
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching pantry from cloud: ${e.message}")
                emptyList()
            }
        } else {
            return emptyList()
        }
    }

    suspend fun syncRecipesToCloud(uid: String, recipes: List<Recipe>): Boolean {
        if (isRealFirebaseEnabled) {
            return try {
                val db = FirebaseFirestore.getInstance()
                val batch = db.batch()
                val collectionRef = db.collection("users").document(uid).collection("recipes")
                
                // Clear existing cloud items
                val snapshot = collectionRef.get().await()
                for (doc in snapshot.documents) {
                    batch.delete(doc.reference)
                }
                
                // Upload current local recipes
                for (recipe in recipes) {
                    val data = hashMapOf(
                        "id" to recipe.id,
                        "name" to recipe.name,
                        "description" to recipe.description,
                        "prepTime" to recipe.prepTime,
                        "cookTime" to recipe.cookTime,
                        "difficulty" to recipe.difficulty,
                        "calories" to recipe.calories,
                        "protein" to recipe.protein,
                        "fat" to recipe.fat,
                        "carbs" to recipe.carbs,
                        "ingredientsJson" to recipe.ingredientsJson,
                        "instructionsJson" to recipe.instructionsJson,
                        "tips" to recipe.tips,
                        "substitutionsJson" to recipe.substitutionsJson,
                        "storageAdvice" to recipe.storageAdvice,
                        "estimatedCost" to recipe.estimatedCost,
                        "servings" to recipe.servings,
                        "isFavorite" to recipe.isFavorite,
                        "inProgressStep" to recipe.inProgressStep,
                        "timestamp" to recipe.timestamp
                    )
                    val docRef = collectionRef.document(if (recipe.id > 0) recipe.id.toString() else UUID.randomUUID().toString())
                    batch.set(docRef, data)
                }
                batch.commit().await()
                true
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing recipes to cloud: ${e.message}")
                false
            }
        } else {
            Log.d(TAG, "Sandbox Sync: Saved custom recipes successfully for user $uid")
            return true
        }
    }

    suspend fun fetchRecipesFromCloud(uid: String): List<Recipe> {
        if (isRealFirebaseEnabled) {
            return try {
                val db = FirebaseFirestore.getInstance()
                val snapshot = db.collection("users").document(uid).collection("recipes").get().await()
                snapshot.documents.mapNotNull { doc ->
                    try {
                        Recipe(
                            id = (doc.getLong("id") ?: 0L).toInt(),
                            name = doc.getString("name") ?: "",
                            description = doc.getString("description") ?: "",
                            prepTime = (doc.getLong("prepTime") ?: 10L).toInt(),
                            cookTime = (doc.getLong("cookTime") ?: 15L).toInt(),
                            difficulty = doc.getString("difficulty") ?: "Easy",
                            calories = (doc.getLong("calories") ?: 200L).toInt(),
                            protein = (doc.getLong("protein") ?: 10L).toInt(),
                            fat = (doc.getLong("fat") ?: 5L).toInt(),
                            carbs = (doc.getLong("carbs") ?: 20L).toInt(),
                            ingredientsJson = doc.getString("ingredientsJson") ?: "[]",
                            instructionsJson = doc.getString("instructionsJson") ?: "[]",
                            tips = doc.getString("tips") ?: "",
                            substitutionsJson = doc.getString("substitutionsJson") ?: "[]",
                            storageAdvice = doc.getString("storageAdvice") ?: "",
                            estimatedCost = doc.getDouble("estimatedCost") ?: 0.0,
                            servings = (doc.getLong("servings") ?: 2L).toInt(),
                            isFavorite = doc.getBoolean("isFavorite") ?: false,
                            inProgressStep = (doc.getLong("inProgressStep") ?: -1L).toInt(),
                            timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                        )
                    } catch (e: Exception) {
                        null
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching recipes from cloud: ${e.message}")
                emptyList()
            }
        } else {
            return emptyList()
        }
    }

    suspend fun syncShoppingToCloud(uid: String, items: List<ShoppingItem>): Boolean {
        if (isRealFirebaseEnabled) {
            return try {
                val db = FirebaseFirestore.getInstance()
                val batch = db.batch()
                val collectionRef = db.collection("users").document(uid).collection("shopping")
                
                // Clear existing cloud items
                val snapshot = collectionRef.get().await()
                for (doc in snapshot.documents) {
                    batch.delete(doc.reference)
                }
                
                // Upload current local items
                for (item in items) {
                    val data = hashMapOf(
                        "id" to item.id,
                        "name" to item.name,
                        "category" to item.category,
                        "quantity" to item.quantity,
                        "unit" to item.unit,
                        "isChecked" to item.isChecked
                    )
                    val docRef = collectionRef.document(if (item.id > 0) item.id.toString() else UUID.randomUUID().toString())
                    batch.set(docRef, data)
                }
                batch.commit().await()
                true
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing shopping to cloud: ${e.message}")
                false
            }
        } else {
            Log.d(TAG, "Sandbox Sync: Shopping list items backed up successfully for user $uid")
            return true
        }
    }

    suspend fun fetchShoppingFromCloud(uid: String): List<ShoppingItem> {
        if (isRealFirebaseEnabled) {
            return try {
                val db = FirebaseFirestore.getInstance()
                val snapshot = db.collection("users").document(uid).collection("shopping").get().await()
                snapshot.documents.mapNotNull { doc ->
                    try {
                        ShoppingItem(
                            id = (doc.getLong("id") ?: 0L).toInt(),
                            name = doc.getString("name") ?: "",
                            category = doc.getString("category") ?: "Produce",
                            quantity = doc.getDouble("quantity") ?: 1.0,
                            unit = doc.getString("unit") ?: "pcs",
                            isChecked = doc.getBoolean("isChecked") ?: false
                        )
                    } catch (e: Exception) {
                        null
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching shopping from cloud: ${e.message}")
                emptyList()
            }
        } else {
            return emptyList()
        }
    }
}

sealed class AuthResult {
    data class Success(val uid: String, val email: String) : AuthResult()
    data class Error(val message: String) : AuthResult()
}
