package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ShoppingBasket
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.example.ui.AppViewModel
import com.example.ui.screens.*
import com.example.ui.theme.CookCanTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CookCanTheme {
                val appViewModel: AppViewModel = viewModel()
                val navController = rememberNavController()

                // Dynamically navigate to home if user is already logged in
                val startDestination = remember { if (appViewModel.isLoggedIn) "home" else "welcome" }

                LaunchedEffect(appViewModel.isLoggedIn) {
                    val currentRoute = navController.currentDestination?.route
                    if (appViewModel.isLoggedIn) {
                        if (currentRoute == "welcome" || currentRoute == null) {
                            navController.navigate("home") {
                                popUpTo("welcome") { inclusive = true }
                            }
                        }
                    } else {
                        if (currentRoute != "welcome") {
                            navController.navigate("welcome") {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    }
                }

                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // Only show bottom navigation if user is logged in AND not on onboarding screen
                        if (appViewModel.isLoggedIn && currentRoute != "welcome" && currentRoute != "camera" && currentRoute != "recipe_detail") {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface,
                                tonalElevation = 8.dp
                            ) {
                                NavigationBarItem(
                                    selected = currentRoute == "home",
                                    onClick = {
                                        navController.navigate("home") {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "Home") },
                                    label = { Text("Home", style = MaterialTheme.typography.labelMedium) }
                                )

                                NavigationBarItem(
                                    selected = currentRoute == "pantry",
                                    onClick = {
                                        navController.navigate("pantry") {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(imageVector = Icons.Default.Kitchen, contentDescription = "Pantry") },
                                    label = { Text("Pantry", style = MaterialTheme.typography.labelMedium) }
                                )

                                NavigationBarItem(
                                    selected = currentRoute == "chat",
                                    onClick = {
                                        navController.navigate("chat") {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(imageVector = Icons.Default.ChatBubble, contentDescription = "AI Chef") },
                                    label = { Text("AI Chef", style = MaterialTheme.typography.labelMedium) }
                                )

                                NavigationBarItem(
                                    selected = currentRoute == "shopping",
                                    onClick = {
                                        navController.navigate("shopping") {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(imageVector = Icons.Default.ShoppingBasket, contentDescription = "Grocery") },
                                    label = { Text("Grocery", style = MaterialTheme.typography.labelMedium) }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = startDestination,
                        modifier = Modifier.padding(innerPadding),
                        enterTransition = { fadeIn(animationSpec = tween(180)) },
                        exitTransition = { fadeOut(animationSpec = tween(180)) },
                        popEnterTransition = { fadeIn(animationSpec = tween(180)) },
                        popExitTransition = { fadeOut(animationSpec = tween(180)) }
                    ) {
                        composable("welcome") {
                            WelcomeScreen(viewModel = appViewModel)
                        }

                        composable("home") {
                            HomeScreen(
                                viewModel = appViewModel,
                                onNavigateToRecipe = { recipeId ->
                                    appViewModel.selectedRecipeId = recipeId
                                    navController.navigate("recipe_detail")
                                },
                                onNavigateToPantry = { navController.navigate("pantry") },
                                onNavigateToShopping = { navController.navigate("shopping") },
                                onNavigateToMealPlanner = { navController.navigate("meal_planner") },
                                onNavigateToProfile = { navController.navigate("profile") },
                                onNavigateToCamera = { navController.navigate("camera") }
                            )
                        }

                        composable("pantry") {
                            PantryScreen(
                                viewModel = appViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable("camera") {
                            CameraScreen(
                                viewModel = appViewModel,
                                onNavigateToRecipes = { navController.navigate("recipes") },
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable("recipes") {
                            RecipeGeneratorScreen(
                                viewModel = appViewModel,
                                onNavigateToRecipe = { recipeId ->
                                    appViewModel.selectedRecipeId = recipeId
                                    navController.navigate("recipe_detail")
                                },
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable("recipe_detail") {
                            RecipeDetailScreen(
                                viewModel = appViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable("chat") {
                            ChatScreen(
                                viewModel = appViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable("meal_planner") {
                            MealPlannerScreen(
                                viewModel = appViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable("shopping") {
                            ShoppingScreen(
                                viewModel = appViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable("profile") {
                            ProfileScreen(
                                viewModel = appViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
