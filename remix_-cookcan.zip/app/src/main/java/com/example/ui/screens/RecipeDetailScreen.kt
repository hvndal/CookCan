package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import android.widget.Toast
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.Recipe
import com.example.ui.AppViewModel
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeDetailScreen(
    viewModel: AppViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val recipe by viewModel.selectedRecipe.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    // Parsing JSON lists
    val moshi = remember { Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build() }
    val listType = remember { Types.newParameterizedType(List::class.java, String::class.java) }
    val adapter = remember { moshi.adapter<List<String>>(listType) }

    // Fallback Mock Recipe if DB item not loaded
    val activeRecipe = recipe ?: Recipe(
        id = 9999,
        name = "Saffron Ravioli with Brown Butter Sage",
        description = "A delicate balance of earthy sage and luxurious saffron threads, hand-folded for perfection.",
        prepTime = 25,
        cookTime = 15,
        difficulty = "Intermediate",
        calories = 420,
        protein = 14,
        fat = 22,
        carbs = 38,
        ingredientsJson = "[\"1 sheet pre-rolled puff pastry\",\"250g seasonal mixed vegetables\",\"100g soft goat cheese\",\"2 sprigs fresh rosemary, chopped\",\"1 egg (for wash)\"]",
        instructionsJson = "[\"Preheat your oven to 200°C (390°F). Roll out the puff pastry onto a parchment-lined baking sheet.\",\"Thinly slice your seasonal vegetables and toss them in olive oil, salt, and fresh chopped rosemary.\",\"Arrange the vegetables inside the pastry border. Dot with goat cheese, brush with egg wash and bake for 20-25 mins.\"]",
        tips = "Chill your pastry in the freezer for 5 minutes before baking to ensure maximum flakiness."
    )

    val ingredientsList = remember(activeRecipe.ingredientsJson) {
        try {
            adapter.fromJson(activeRecipe.ingredientsJson) ?: emptyList()
        } catch (e: Exception) {
            listOf("1 sheet pre-rolled puff pastry", "250g vegetables", "100g goat cheese")
        }
    }

    val instructionsList = remember(activeRecipe.instructionsJson) {
        try {
            adapter.fromJson(activeRecipe.instructionsJson) ?: emptyList()
        } catch (e: Exception) {
            listOf("Step 1: Roll the pastry.", "Step 2: Add vegetables.", "Step 3: Bake.")
        }
    }

    // Active Cooking State
    var isCookingMode by remember { mutableStateOf(activeRecipe.inProgressStep >= 0) }
    var currentStepIndex by remember { mutableStateOf(if (activeRecipe.inProgressStep >= 0) activeRecipe.inProgressStep else 0) }

    // Timer States
    var timerSecondsRemaining by remember { mutableIntStateOf(1200) } // 20:00 mins default
    var isTimerRunning by remember { mutableStateOf(false) }

    // Text to Speech indicator
    var isVoiceActive by remember { mutableStateOf(false) }

    // Timer countdown effect
    LaunchedEffect(isTimerRunning) {
        if (isTimerRunning) {
            while (timerSecondsRemaining > 0 && isTimerRunning) {
                delay(1000)
                timerSecondsRemaining--
            }
            if (timerSecondsRemaining == 0) {
                isTimerRunning = false
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        if (!isCookingMode) {
            // VIEW 1: Standard Gourmet Recipe Details page
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                bottomBar = {
                    Surface(
                        color = Color.White,
                        tonalElevation = 8.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                    ) {
                        Button(
                            onClick = {
                                isCookingMode = true
                                viewModel.updateCookingStep(activeRecipe, 0)
                            },
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp)
                                .height(56.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Restaurant, contentDescription = "Chef hat")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Start Cooking",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(MaterialTheme.colorScheme.background)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Header Image with Back button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data("https://lh3.googleusercontent.com/aida-public/AB6AXuD23RX2ExpoVbhgJzXkxgBa_h_edQ5nXED2qqot3CZHIWXsabOCgxn0e8wR2GDiQo2K36JMHuN_C8moPqnEeWvEV1GXxHpqaf5oMeRp-237YEioxiFIsigxXNk674BuiibCbAHiYjuH3pKkIvIlJyJzyD3ZSMeZVCxFZCrsf_HYTxOg_YyJT4HPSB0Pa6HhhdBcZYuG2mKPvQXP0vQIeu2TIxDLsl__DunGo8nUBagpqotOWb5ItPgf")
                                .crossfade(true)
                                .build(),
                            contentDescription = activeRecipe.name,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )

                        // Dark Gradient Overlay
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color.Black.copy(alpha = 0.5f), Color.Transparent)
                                    )
                                )
                        )

                        // Actions overlay
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .statusBarsPadding()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = onNavigateBack,
                                modifier = Modifier.background(Color.Black.copy(alpha = 0.4f), CircleShape)
                            ) {
                                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IconButton(
                                    onClick = { viewModel.toggleFavoriteRecipe(activeRecipe) },
                                    modifier = Modifier.background(Color.Black.copy(alpha = 0.4f), CircleShape)
                                ) {
                                    Icon(
                                        imageVector = if (activeRecipe.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Favorite",
                                        tint = if (activeRecipe.isFavorite) MaterialTheme.colorScheme.primary else Color.White
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        val shareText = formatRecipeForSharing(activeRecipe, ingredientsList, instructionsList)
                                        clipboardManager.setText(AnnotatedString(shareText))
                                        Toast.makeText(context, "Copied to clipboard! Opening share options...", Toast.LENGTH_SHORT).show()
                                        try {
                                            val sendIntent = android.content.Intent().apply {
                                                action = android.content.Intent.ACTION_SEND
                                                putExtra(android.content.Intent.EXTRA_TEXT, shareText)
                                                type = "text/plain"
                                            }
                                            val shareIntent = android.content.Intent.createChooser(sendIntent, null)
                                            context.startActivity(shareIntent)
                                        } catch (e: Exception) {
                                            // Fallback
                                        }
                                    },
                                    modifier = Modifier
                                        .background(Color.Black.copy(alpha = 0.4f), CircleShape)
                                        .testTag("share_recipe_button")
                                ) {
                                    Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                                }
                            }
                        }
                    }

                    // Recipe Metadata Title block
                    Column(modifier = Modifier.padding(24.dp)) {
                        Text(
                            text = activeRecipe.name,
                            style = MaterialTheme.typography.displayLarge.copy(fontSize = 32.sp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = activeRecipe.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        // Nutritional Panels
                        Text(
                            text = "NUTRITIONAL INFO",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            NutritionalChip(label = "Calories", value = "${activeRecipe.calories} kcal")
                            NutritionalChip(label = "Protein", value = "${activeRecipe.protein}g")
                            NutritionalChip(label = "Fats", value = "${activeRecipe.fat}g")
                            NutritionalChip(label = "Carbs", value = "${activeRecipe.carbs}g")
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Chef's Secret Callout
                        if (activeRecipe.tips.isNotBlank()) {
                            Surface(
                                color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.2f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = "Tips",
                                        tint = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "Chef's Secret",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.tertiary
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = activeRecipe.tips,
                                            style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Ingredients list checkboxes
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "INGREDIENTS",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.outline
                            )
                            Text(
                                text = "${ingredientsList.size} items",
                                style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.primary)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        ingredientsList.forEach { ing ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Real-time Pantry Mapping Checkbox (Pre-check items we scanned / have!)
                                val isItemInStock = remember(ing) {
                                    ing.contains("puff pastry", true) || ing.contains("vegetables", true) || ing.contains("cheese", true)
                                }
                                Icon(
                                    imageVector = if (isItemInStock) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = "Status",
                                    tint = if (isItemInStock) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = ing,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isItemInStock) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // VIEW 2: Fullscreen Interactive step-by-step Cooking Mode
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Active Cooking Mode", style = MaterialTheme.typography.headlineSmall) },
                        navigationIcon = {
                            IconButton(onClick = {
                                isCookingMode = false
                                viewModel.updateCookingStep(activeRecipe, -1)
                            }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Exit")
                            }
                        },
                        actions = {
                            // Text To Speech simulated voice assistant trigger
                            IconButton(onClick = { isVoiceActive = !isVoiceActive }) {
                                Icon(
                                    imageVector = if (isVoiceActive) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                                    contentDescription = "Voice Reader",
                                    tint = if (isVoiceActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    )
                },
                modifier = Modifier.fillMaxSize()
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(MaterialTheme.colorScheme.background)
                        .padding(24.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header progress bar
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        LinearProgressIndicator(
                            progress = { (currentStepIndex + 1).toFloat() / instructionsList.size.toFloat() },
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Step ${currentStepIndex + 1} of ${instructionsList.size}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Huge instruction card centering
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 32.dp),
                        shadowElevation = 4.dp
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = instructionsList[currentStepIndex],
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontSize = 24.sp,
                                    lineHeight = 36.sp,
                                    textAlign = TextAlign.Center
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(32.dp))

                            // Simulated Active Cooking Timer
                            val minutes = timerSecondsRemaining / 60
                            val seconds = timerSecondsRemaining % 60
                            val timeStr = String.format("%02d:%02d", minutes, seconds)

                            Surface(
                                onClick = { isTimerRunning = !isTimerRunning },
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                shape = CircleShape,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f))
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isTimerRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Timer toggle",
                                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Timer: $timeStr",
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }
                    }

                    // Back/Next Navigation control footer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = {
                                if (currentStepIndex > 0) {
                                    currentStepIndex--
                                    viewModel.updateCookingStep(activeRecipe, currentStepIndex)
                                }
                            },
                            enabled = currentStepIndex > 0
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.ArrowBackIos, contentDescription = "Prev", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("PREVIOUS")
                            }
                        }

                        if (currentStepIndex == instructionsList.size - 1) {
                            Button(
                                onClick = {
                                    isCookingMode = false
                                    viewModel.updateCookingStep(activeRecipe, -1)
                                    onNavigateBack()
                                },
                                shape = CircleShape,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                contentPadding = PaddingValues(horizontal = 32.dp, vertical = 16.dp)
                            ) {
                                Text(
                                    text = "Finish Cooking",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        } else {
                            Button(
                                onClick = {
                                    currentStepIndex++
                                    viewModel.updateCookingStep(activeRecipe, currentStepIndex)
                                },
                                shape = CircleShape,
                                contentPadding = PaddingValues(horizontal = 32.dp, vertical = 16.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "NEXT STEP",
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(imageVector = Icons.Default.ArrowForwardIos, contentDescription = "Next", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Text To Speech Speaking indicator hud overlay
            if (isVoiceActive) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(24.dp, 24.dp, 0.dp, 0.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Mic",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(Color.White, CircleShape)
                                    .padding(8.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Voice Assistant Active",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "\"Say 'Next Step' or 'Preheat oven' to control hands-free!\"",
                                style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NutritionalChip(label: String, value: String) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        modifier = Modifier.width(76.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.outline,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

fun formatRecipeForSharing(recipe: Recipe, ingredients: List<String>, instructions: List<String>): String {
    val sb = StringBuilder()
    sb.append("🍳 ${recipe.name} 🍳\n\n")
    if (recipe.description.isNotBlank()) {
        sb.append("${recipe.description}\n\n")
    }
    sb.append("⏱️ Prep Time: ${recipe.prepTime} mins | Cook Time: ${recipe.cookTime} mins\n")
    sb.append("🔥 Calories: ${recipe.calories} kcal\n")
    sb.append("💪 Protein: ${recipe.protein}g | Fats: ${recipe.fat}g | Carbs: ${recipe.carbs}g\n\n")
    
    if (ingredients.isNotEmpty()) {
        sb.append("🛒 INGREDIENTS:\n")
        ingredients.forEach { ing ->
            sb.append("- $ing\n")
        }
        sb.append("\n")
    }
    
    if (instructions.isNotEmpty()) {
        sb.append("📝 INSTRUCTIONS:\n")
        instructions.forEachIndexed { index, step ->
            sb.append("${index + 1}. $step\n")
        }
    }
    
    if (recipe.tips.isNotBlank()) {
        sb.append("\n💡 CHEF'S TIP: ${recipe.tips}\n")
    }
    
    sb.append("\nShared via Gourmet AI Studio App ✨")
    return sb.toString()
}

