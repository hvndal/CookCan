package com.example.ui.theme

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

/**
 * A highly satisfying, spring-loaded bounce click modifier.
 * Scales down the element on press using Compose's interaction source for seamless click handling.
 */
fun Modifier.bounceClick(
    enabled: Boolean = true,
    onClick: (() -> Unit)? = null
): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) 0.95f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "BounceClickScale"
    )

    if (enabled) {
        val modifierWithScale = this.scale(scale)
        if (onClick != null) {
            modifierWithScale.clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
        } else {
            modifierWithScale
        }
    } else {
        this
    }
}

/**
 * A subtle, continuous breathing pulsate animation to highlight high-priority action buttons.
 */
fun Modifier.pulsate(
    minScale: Float = 0.96f,
    maxScale: Float = 1.04f,
    durationMillis: Int = 1200
): Modifier = composed {
    val infiniteTransition = rememberInfiniteTransition(label = "Pulsate")
    val scale by infiniteTransition.animateFloat(
        initialValue = minScale,
        targetValue = maxScale,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulsateScale"
    )
    this.scale(scale)
}

/**
 * Confetti particle state representation
 */
data class ConfettiParticle(
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val color: Color,
    val size: Float,
    val rotation: Float,
    val rotSpeed: Float,
    val alpha: Float
)

/**
 * Playful confetti explosion Composable.
 * Spawns dynamic physical confetti particles with spread, gravity, rotation, and alpha fade.
 */
@Composable
fun ConfettiEffect(
    trigger: Boolean,
    onFinished: () -> Unit
) {
    if (!trigger) return

    val particles = remember { mutableStateListOf<ConfettiParticle>() }
    val scope = rememberCoroutineScope()
    var isRunning by remember { mutableStateOf(true) }

    // Colors used for particles (vibrant Duolingo/gourmet-style palette)
    val colors = listOf(
        Color(0xFFFF5722), // Vibrant Orange
        Color(0xFF4CAF50), // Fresh Green
        Color(0xFF2196F3), // Tech Blue
        Color(0xFFFFEB3B), // Sunny Yellow
        Color(0xFFE91E63), // Punchy Pink
        Color(0xFF9C27B0)  // Purple Royal
    )

    // Explode particles from screen center or bottom
    LaunchedEffect(trigger) {
        particles.clear()
        // Spawn 45 particles with random launch velocities
        repeat(45) {
            val angle = Random.nextFloat() * Math.PI.toFloat() * 2f
            val speed = Random.nextFloat() * 15f + 10f
            particles.add(
                ConfettiParticle(
                    x = 0.5f, // Normalized screen horizontal center
                    y = 0.4f, // Screen vertical height center
                    vx = kotlin.math.cos(angle) * speed,
                    vy = kotlin.math.sin(angle) * speed - 5f, // Initial upwards bias
                    color = colors.random(),
                    size = Random.nextFloat() * 12f + 8f,
                    rotation = Random.nextFloat() * 360f,
                    rotSpeed = Random.nextFloat() * 20f - 10f,
                    alpha = 1.0f
                )
            )
        }

        // Run animation loop (approx 60-120fps)
        scope.launch {
            while (isRunning && particles.any { it.alpha > 0.05f }) {
                delay(16) // Approx 60fps frame delta
                for (i in particles.indices) {
                    val p = particles[i]
                    if (p.alpha > 0.05f) {
                        particles[i] = p.copy(
                            x = p.x + p.vx * 0.002f,
                            y = p.y + p.vy * 0.002f + 0.005f, // Gravity pull
                            vy = p.vy + 0.3f, // Gravity acceleration
                            rotation = p.rotation + p.rotSpeed,
                            alpha = (p.alpha - 0.015f).coerceAtLeast(0f)
                        )
                    }
                }
            }
            isRunning = false
            onFinished()
        }
    }

    if (isRunning) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            particles.forEach { p ->
                if (p.alpha > 0f) {
                    rotate(p.rotation, pivot = Offset(p.x * w, p.y * h)) {
                        drawRect(
                            color = p.color.copy(alpha = p.alpha),
                            topLeft = Offset(p.x * w - p.size / 2, p.y * h - p.size / 2),
                            size = androidx.compose.ui.geometry.Size(p.size, p.size * 1.5f)
                        )
                    }
                }
            }
        }
    }
}
