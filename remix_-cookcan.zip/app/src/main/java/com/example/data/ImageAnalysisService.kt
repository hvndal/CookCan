package com.example.data

import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Base64
import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.IOException

/**
 * Service responsible for processing, optimizing, and analyzing camera frame images using the Gemini API,
 * parsing structured JSON responses into strongly-typed culinary ingredient data objects.
 */
class ImageAnalysisService(private val apiService: GeminiApiService) {

    private val tag = "ImageAnalysisService"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    /**
     * Optimizes a Bitmap (resizes and compresses) and converts it to Base64.
     */
    fun optimizeAndEncodeBitmap(bitmap: Bitmap, maxDimension: Int = 1024, quality: Int = 80): String {
        val width = bitmap.width
        val height = bitmap.height
        
        // Scale down if any dimension exceeds maxDimension to reduce payload size & network latency
        val scaledBitmap = if (width > maxDimension || height > maxDimension) {
            val ratio = width.toFloat() / height.toFloat()
            val newWidth: Int
            val newHeight: Int
            if (ratio > 1) {
                newWidth = maxDimension
                newHeight = (maxDimension / ratio).toInt()
            } else {
                newHeight = maxDimension
                newWidth = (maxDimension * ratio).toInt()
            }
            Log.d(tag, "Resizing image from ${width}x${height} to ${newWidth}x${newHeight}")
            Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
        } else {
            bitmap
        }

        val outputStream = ByteArrayOutputStream()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        val byteArray = outputStream.toByteArray()
        
        Log.d(tag, "Compressed image size: ${byteArray.size / 1024} KB")
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }

    /**
     * Sends a captured image to Gemini API and parses the JSON response into a list of ingredients.
     *
     * @param base64Image Base64-encoded JPEG image data.
     * @return List of parsed [GeminiIngredientJson] objects.
     */
    suspend fun analyzeImageForIngredients(base64Image: String): List<GeminiIngredientJson> = withContext(Dispatchers.IO) {
        val apiKey = GeminiClient.getApiKey()
        if (apiKey.isEmpty()) {
            throw IOException("Gemini API Key is not set. Please configure it in AI Studio Secrets panel.")
        }

        val prompt = """
            Analyze this image of kitchen countertop contents, pantry, or refrigerator.
            Identify all visible food ingredients, raw materials, condiments, produce, meats, or spices.
            Return a structured JSON list of detected ingredients.
            Do not include any other conversational filler text, markdown formatting blocks (like ```json), or commentary. Use this exact JSON structure:
            [
              {
                "name": "Ingredient Name",
                "quantity": 1.0,
                "unit": "pcs/g/ml/lbs/oz/cups/tbsp/tsp/can/bottle/bulb/sprig",
                "category": "Produce/Meat/Dairy/Pantry/Spices/Other",
                "confidence": 0.95,
                "freshness": "Fresh/Ripe/Expiring Soon"
              }
            ]
        """.trimIndent()

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(
                        GeminiPart(text = prompt),
                        GeminiPart(inlineData = InlineData(mimeType = "image/jpeg", data = base64Image))
                    )
                )
            ),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.2f
            )
        )

        Log.d(tag, "Sending request to Gemini API model: gemini-3.5-flash...")
        val response = apiService.generateContent(apiKey, request)
        val responseText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            ?: throw IOException("Empty response received from Gemini API.")

        Log.d(tag, "Raw Gemini Response: $responseText")
        val cleanedJson = cleanMarkdownJson(responseText)
        Log.d(tag, "Cleaned JSON Response: $cleanedJson")

        return@withContext try {
            val listType = Types.newParameterizedType(List::class.java, GeminiIngredientJson::class.java)
            val adapter = moshi.adapter<List<GeminiIngredientJson>>(listType)
            adapter.fromJson(cleanedJson) ?: emptyList()
        } catch (e: Exception) {
            Log.e(tag, "Moshi JSON parsing failed: ${e.message}", e)
            throw IOException("Failed to parse the structured ingredient data from the AI's response.", e)
        }
    }

    /**
     * Cleans markdown blocks (e.g. ```json ... ```) often returned by LLMs.
     */
    private fun cleanMarkdownJson(text: String): String {
        var cleaned = text.trim()
        if (cleaned.startsWith("```json")) {
            cleaned = cleaned.substringAfter("```json")
        } else if (cleaned.startsWith("```")) {
            cleaned = cleaned.substringAfter("```")
        }
        if (cleaned.endsWith("```")) {
            cleaned = cleaned.substringBeforeLast("```")
        }
        return cleaned.trim()
    }
}
