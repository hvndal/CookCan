package com.example

import com.example.data.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ImageAnalysisServiceTest {

    // A simple Mock Gemini API Service to stub responses for testing
    private class FakeGeminiApiService(private val responseText: String) : GeminiApiService {
        override suspend fun generateContent(apiKey: String, request: GeminiRequest): GeminiResponse {
            val part = GeminiPart(text = responseText)
            val content = GeminiContent(parts = listOf(part))
            val candidate = GeminiCandidate(content = content)
            return GeminiResponse(candidates = listOf(candidate))
        }
    }

    @Test
    fun `analyzeImageForIngredients parses valid JSON list correctly`() = runBlocking {
        val sampleResponse = """
            [
              {
                "name": "Roma Tomato",
                "quantity": 3.0,
                "unit": "pcs",
                "category": "Produce",
                "confidence": 0.98,
                "freshness": "Ripe"
              },
              {
                "name": "Fresh Rosemary",
                "quantity": 2.0,
                "unit": "sprigs",
                "category": "Spices",
                "confidence": 0.92,
                "freshness": "Fresh"
              }
            ]
        """.trimIndent()

        val service = ImageAnalysisService(FakeGeminiApiService(sampleResponse))
        val ingredients = service.analyzeImageForIngredients("mockBase64String")

        assertEquals(2, ingredients.size)
        
        val tomato = ingredients[0]
        assertEquals("Roma Tomato", tomato.name)
        assertEquals(3.0, tomato.quantity, 0.001)
        assertEquals("pcs", tomato.unit)
        assertEquals("Produce", tomato.category)
        assertEquals(0.98, tomato.confidence, 0.001)
        assertEquals("Ripe", tomato.freshness)

        val rosemary = ingredients[1]
        assertEquals("Fresh Rosemary", rosemary.name)
        assertEquals(2.0, rosemary.quantity, 0.001)
        assertEquals("sprigs", rosemary.unit)
        assertEquals("Spices", rosemary.category)
        assertEquals(0.92, rosemary.confidence, 0.001)
        assertEquals("Fresh", rosemary.freshness)
    }

    @Test
    fun `analyzeImageForIngredients cleans markdown wrappers before parsing`() = runBlocking {
        val sampleResponseWithMarkdown = """
            ```json
            [
              {
                "name": "Atlantic Salmon",
                "quantity": 1.0,
                "unit": "lb",
                "category": "Meat",
                "confidence": 0.99,
                "freshness": "Fresh"
              }
            ]
            ```
        """.trimIndent()

        val service = ImageAnalysisService(FakeGeminiApiService(sampleResponseWithMarkdown))
        val ingredients = service.analyzeImageForIngredients("mockBase64String")

        assertEquals(1, ingredients.size)
        val salmon = ingredients[0]
        assertEquals("Atlantic Salmon", salmon.name)
        assertEquals(1.0, salmon.quantity, 0.001)
        assertEquals("lb", salmon.unit)
        assertEquals("Meat", salmon.category)
    }

    @Test(expected = IOException::class)
    fun `analyzeImageForIngredients throws IOException on empty API response`(): Unit = runBlocking {
        val service = ImageAnalysisService(FakeGeminiApiService(""))
        service.analyzeImageForIngredients("mockBase64String")
    }
}
