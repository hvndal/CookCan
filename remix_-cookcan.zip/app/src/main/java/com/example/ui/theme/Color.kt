package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFFA43758)
val OnPrimary = Color(0xFFFFFFFF)
val PrimaryContainer = Color(0xFFF07293)
val OnPrimaryContainer = Color(0xFF69042D)

val Secondary = Color(0xFF53634D)
val OnSecondary = Color(0xFFFFFFFF)
val SecondaryContainer = Color(0xFFD7E8CC)
val OnSecondaryContainer = Color(0xFF596953)

val Tertiary = Color(0xFF97472F)
val OnTertiary = Color(0xFFFFFFFF)
val TertiaryContainer = Color(0xFFE18165)
val OnTertiaryContainer = Color(0xFF5E1D08)

val Background = Color(0xFFFBF9F5)
val OnBackground = Color(0xFF1B1C1A)

val Surface = Color(0xFFFBF9F5)
val OnSurface = Color(0xFF1B1C1A)
val SurfaceVariant = Color(0xFFE4E2DE)
val OnSurfaceVariant = Color(0xFF564245)

val Outline = Color(0xFF897175)
val OutlineVariant = Color(0xFFDCC0C4)

val Error = Color(0xFFBA1A1A)
val OnError = Color(0xFFFFFFFF)
val ErrorContainer = Color(0xFFFFDAD6)
val OnErrorContainer = Color(0xFF93000A)

// Specific surface layers for the glass effects & cards
val SurfaceContainerLowest = Color(0xFFFFFFFF)
val SurfaceContainerLow = Color(0xFFF5F3EF)
val SurfaceContainer = Color(0xFFEFEEEA)
val SurfaceContainerHigh = Color(0xFFEAE8E4)
val SurfaceContainerHighest = Color(0xFFE4E2DE)
