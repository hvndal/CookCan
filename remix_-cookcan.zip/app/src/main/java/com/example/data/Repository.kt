package com.example.data

import android.content.Context
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.IOException

// Raw JSON models for Moshi parsing
data class GeminiIngredientJson(
    val name: String,
    val quantity: Double,
    val unit: String,
    val category: String,
    val confidence: Double = 1.0,
    val freshness: String = "Fresh"
)

data class GeminiRecipeJson(
    val name: String,
    val description: String,
    val prepTime: Int,
    val cookTime: Int,
    val difficulty: String,
    val calories: Int,
    val protein: Int,
    val fat: Int,
    val carbs: Int,
    val ingredients: List<String>,
    val instructions: List<String>,
    val tips: String = "",
    val substitutions: List<String> = emptyList(),
    val storageAdvice: String = "",
    val estimatedCost: Double = 0.0,
    val servings: Int = 2
)

class CookCanRepository(private val db: AppDatabase) {

    val pantryDao = db.pantryDao()
    val recipeDao = db.recipeDao()
    val shoppingDao = db.shoppingDao()
    val mealPlanDao = db.mealPlanDao()
    val chatDao = db.chatDao()

    val imageAnalysisService = ImageAnalysisService(GeminiClient.apiService)

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    // Pantry methods
    fun getAllPantryItems(): Flow<List<PantryItem>> = pantryDao.getAllItems()
    fun searchPantry(query: String): Flow<List<PantryItem>> {
        return if (query.isBlank()) {
            pantryDao.getAllItems()
        } else {
            pantryDao.searchItems("%$query%")
        }
    }
    suspend fun insertPantryItem(item: PantryItem) = pantryDao.insertItem(item)
    suspend fun updatePantryItem(item: PantryItem) = pantryDao.updateItem(item)
    suspend fun deletePantryItem(id: Int) = pantryDao.deleteById(id)
    suspend fun clearPantry() = pantryDao.clearPantry()

    // Recipe methods
    fun getAllRecipes(): Flow<List<Recipe>> = recipeDao.getAllRecipes()
    fun getRecipeById(id: Int): Flow<Recipe?> = recipeDao.getRecipeById(id)
    fun getFavoriteRecipes(): Flow<List<Recipe>> = recipeDao.getFavoriteRecipes()
    fun getInProgressRecipes(): Flow<List<Recipe>> = recipeDao.getInProgressRecipes()
    suspend fun insertRecipe(recipe: Recipe): Long = recipeDao.insertRecipe(recipe)
    suspend fun updateRecipe(recipe: Recipe) = recipeDao.updateRecipe(recipe)
    suspend fun deleteRecipe(id: Int) = recipeDao.deleteById(id)

    // Shopping List methods
    fun getAllShoppingItems(): Flow<List<ShoppingItem>> = shoppingDao.getAllItems()
    suspend fun insertShoppingItem(item: ShoppingItem) = shoppingDao.insertItem(item)
    suspend fun updateShoppingItem(item: ShoppingItem) = shoppingDao.updateItem(item)
    suspend fun deleteShoppingItem(id: Int) = shoppingDao.deleteById(id)
    suspend fun clearCheckedShoppingItems() = shoppingDao.clearChecked()

    // Meal Plan methods
    fun getAllMealPlans(): Flow<List<MealPlanItem>> = mealPlanDao.getAllMealPlans()
    fun getMealPlansForDate(date: String): Flow<List<MealPlanItem>> = mealPlanDao.getMealPlansForDate(date)
    suspend fun insertMealPlan(item: MealPlanItem) = mealPlanDao.insertMealPlan(item)
    suspend fun deleteMealPlan(item: MealPlanItem) = mealPlanDao.deleteMealPlan(item)

    // Chat methods
    fun getChatHistory(): Flow<List<ChatMessage>> = chatDao.getChatHistory()
    suspend fun insertChatMessage(role: String, text: String) {
        chatDao.insertMessage(ChatMessage(role = role, text = text))
    }
    suspend fun clearChatHistory() = chatDao.clearHistory()

    /**
     * Camera Scan: Sends base64 image to Gemini and decodes the detected ingredients.
     */
    suspend fun scanIngredientsFromImage(base64Image: String): List<PantryItem> = withContext(Dispatchers.IO) {
        try {
            val parsedIngredients = imageAnalysisService.analyzeImageForIngredients(base64Image)

            val pantryItems = parsedIngredients.map {
                PantryItem(
                    name = it.name,
                    quantity = it.quantity,
                    unit = it.unit,
                    category = it.category,
                    confidence = it.confidence,
                    freshness = it.freshness,
                    purchaseDate = System.currentTimeMillis(),
                    expirationDate = System.currentTimeMillis() + (7 * 24 * 60 * 60 * 1000) // Default 7 days
                )
            }

            // Batch insert into Room database
            pantryDao.insertItems(pantryItems)
            pantryItems
        } catch (e: Exception) {
            e.printStackTrace()
            throw e
        }
    }

    /**
     * Recipe Generator: Takes user selections and requests Gemini to create custom recipes.
     */
    suspend fun generateRecipes(
        cuisine: String,
        mealType: String,
        maxTimeMinutes: Int,
        pantryIngredients: List<PantryItem>,
        additionalPreferences: String = ""
    ): List<Recipe> = withContext(Dispatchers.IO) {
        val apiKey = GeminiClient.getApiKey()
        if (apiKey.isEmpty()) {
            throw IOException("Gemini API Key is not set in AI Studio Secrets panel.")
        }

        val pantryNames = pantryIngredients.joinToString(", ") { "${it.quantity} ${it.unit} ${it.name}" }
        val prompt = """
            Create three completely custom recipes tailored exactly to my available kitchen pantry items.
            The tone of the recipes, descriptions, and tips should be warm, friendly, welcoming, and down-to-earth, rather than over-the-top or overly fancy gourmet style. Keep suggestions cozy, practical, and highly encouraging!
            
            Available items: $pantryNames
            Cuisine style preference: $cuisine
            Meal type preference: $mealType
            Maximum cooking/prep time: $maxTimeMinutes minutes
            ${if (additionalPreferences.isNotBlank()) "Additional custom requirements and user requests: $additionalPreferences" else ""}
            
            Return a structured JSON list of recipes. Do not include markdown blocks, code brackets, or commentary. Use this format:
            [
              {
                "name": "Recipe Name",
                "description": "A warm, friendly, and cozy short description of the dish.",
                "prepTime": 15,
                "cookTime": 20,
                "difficulty": "Easy/Intermediate/Advanced",
                "calories": 350,
                "protein": 15,
                "fat": 10,
                "carbs": 40,
                "ingredients": ["1.5 lbs Salmon fillet", "1 sprig Rosemary", "1 tbsp Olive oil"],
                "instructions": ["Step 1 directions here.", "Step 2 directions here."],
                "tips": "A warm, friendly, and practical kitchen suggestion from an encouraging home chef.",
                "substitutions": ["Replace Rosemary with Sage if desired"],
                "storageAdvice": "Keep refrigerated for up to 3 days.",
                "estimatedCost": 12.50,
                "servings": 2
              }
            ]
        """.trimIndent()

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(parts = listOf(GeminiPart(text = prompt)))
            ),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.7f
            )
        )

        try {
            val response = GeminiClient.apiService.generateContent(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: throw IOException("Empty response received from Gemini.")

            val cleanedJsonText = cleanMarkdownJson(jsonText)

            val listType = Types.newParameterizedType(List::class.java, GeminiRecipeJson::class.java)
            val adapter = moshi.adapter<List<GeminiRecipeJson>>(listType)
            val parsedRecipes = adapter.fromJson(cleanedJsonText) ?: emptyList()

            val listOfStringAdapter = moshi.adapter<List<String>>(Types.newParameterizedType(List::class.java, String::class.java))

            val recipes = parsedRecipes.map {
                Recipe(
                    name = it.name,
                    description = it.description,
                    prepTime = it.prepTime,
                    cookTime = it.cookTime,
                    difficulty = it.difficulty,
                    calories = it.calories,
                    protein = it.protein,
                    fat = it.fat,
                    carbs = it.carbs,
                    ingredientsJson = listOfStringAdapter.toJson(it.ingredients),
                    instructionsJson = listOfStringAdapter.toJson(it.instructions),
                    tips = it.tips,
                    substitutionsJson = listOfStringAdapter.toJson(it.substitutions),
                    storageAdvice = it.storageAdvice,
                    estimatedCost = it.estimatedCost,
                    servings = it.servings
                )
            }

            // Save in database
            val recipesWithId = recipes.map { recipe ->
                val insertedId = recipeDao.insertRecipe(recipe)
                recipe.copy(id = insertedId.toInt())
            }

            recipesWithId
        } catch (e: Exception) {
            e.printStackTrace()
            throw e
        }
    }

    /**
     * AI Chat Assistant: Chat naturally, remembering previous history inside local storage.
     */
    suspend fun getAIChatResponse(history: List<ChatMessage>, currentMessage: String): String = withContext(Dispatchers.IO) {
        val apiKey = GeminiClient.getApiKey()
        if (apiKey.isEmpty()) {
            throw IOException("Gemini API Key is not set.")
        }

        val systemInstruction = """
            You are a warm, friendly, and supportive kitchen companion and home chef helper inside the user's phone.
            Help them answer 'What should I cook right now?' with smart, encouraging culinary advice, reducing food waste.
            Keep your answers warm, highly encouraging, cozy, conversational, practical, and down-to-earth. Do not be overly fancy, pretentious, or over-the-top. Speak like a welcoming, friendly neighbor who loves cooking!
        """.trimIndent()

        // Build Gemini conversation contents from chat history
        val contents = mutableListOf<GeminiContent>()
        for (msg in history) {
            contents.add(
                GeminiContent(
                    role = msg.role,
                    parts = listOf(GeminiPart(text = msg.text))
                )
            )
        }
        contents.add(
            GeminiContent(
                role = "user",
                parts = listOf(GeminiPart(text = currentMessage))
            )
        )

        val request = GeminiRequest(
            contents = contents,
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemInstruction))),
            generationConfig = GenerationConfig(temperature = 0.7f)
        )

        try {
            val response = GeminiClient.apiService.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "My apologies, Chef. I am unable to answer right now."
        } catch (e: Exception) {
            e.printStackTrace()
            "Error communicating with Gemini: ${e.message}"
        }
    }

    private fun cleanMarkdownJson(text: String): String {
        var cleaned = text.trim()
        if (cleaned.startsWith("```json")) {
            cleaned = cleaned.substringAfter("```json")
        } else if (cleaned.startsWith("```")) {
            cleaned = cleaned.substringAfter("```")
        }
        if (cleaned.endsWith("```")) {
            cleaned = cleaned.substringBeforeLast("```")
        }
        return cleaned.trim()
    }
}
