package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pantry_items")
data class PantryItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val quantity: Double,
    val unit: String,
    val purchaseDate: Long,
    val expirationDate: Long,
    val category: String,
    val confidence: Double = 1.0,
    val freshness: String = "Fresh"
)

@Entity(tableName = "recipes")
data class Recipe(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val prepTime: Int, // in minutes
    val cookTime: Int, // in minutes
    val difficulty: String, // Easy, Intermediate, Advanced
    val calories: Int,
    val protein: Int,
    val fat: Int,
    val carbs: Int,
    val ingredientsJson: String, // Serialized List of strings or objects
    val instructionsJson: String, // Serialized List of strings
    val tips: String = "",
    val substitutionsJson: String = "[]",
    val storageAdvice: String = "",
    val estimatedCost: Double = 0.0,
    val servings: Int = 2,
    val isFavorite: Boolean = false,
    val inProgressStep: Int = -1, // -1 means not started, 0 to N for current step
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "shopping_items")
data class ShoppingItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String,
    val quantity: Double = 1.0,
    val unit: String = "pcs",
    val isChecked: Boolean = false
)

@Entity(tableName = "meal_plans")
data class MealPlanItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // YYYY-MM-DD
    val mealType: String, // Breakfast, Lunch, Dinner, Snack
    val recipeId: Int? = null,
    val recipeName: String,
    val calories: Int = 0,
    val protein: Int = 0
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val role: String, // "user" or "model"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)
