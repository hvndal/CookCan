package com.example.ui

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CookCanRepository
    private val prefs = application.getSharedPreferences("cookcan_prefs", Context.MODE_PRIVATE)

    // Auth State
    var isLoggedIn by mutableStateOf(prefs.getBoolean("is_logged_in", false))
        private set
    var userEmail by mutableStateOf(prefs.getString("user_email", "") ?: "")
        private set
    var userUid by mutableStateOf(prefs.getString("user_uid", "") ?: "")
        private set

    // Firebase Connection Status
    var isRealFirebaseEnabled by mutableStateOf(false)
        private set
    var isSyncInProgress by mutableStateOf(false)
    var lastSyncTimestamp by mutableStateOf(prefs.getLong("last_sync_timestamp", 0L))
    var authErrorMessage by mutableStateOf<String?>(null)

    // Database Flows
    val pantryItems: StateFlow<List<PantryItem>>
    val recipes: StateFlow<List<Recipe>>
    val shoppingItems: StateFlow<List<ShoppingItem>>
    val mealPlanItems: StateFlow<List<MealPlanItem>>
    val chatHistory: StateFlow<List<ChatMessage>>

    // UI Loading States
    var isScanning by mutableStateOf(false)
    var isGeneratingRecipe by mutableStateOf(false)
        private set
    var generatedRecipesState by mutableStateOf<List<Recipe>>(emptyList())
        private set
    var isChatLoading by mutableStateOf(false)
        private set

    // Error Messaging
    var errorMessage by mutableStateOf<String?>(null)

    // Navigation Helper (Active Recipe Detail)
    private val _selectedRecipe = MutableStateFlow<Recipe?>(null)
    val selectedRecipe: StateFlow<Recipe?> = _selectedRecipe.asStateFlow()

    private val _selectedRecipeId = mutableStateOf<Int?>(null)
    var selectedRecipeId: Int?
        get() = _selectedRecipeId.value
        set(value) {
            _selectedRecipeId.value = value
            if (value != null) {
                viewModelScope.launch {
                    repository.getRecipeById(value).collect {
                        _selectedRecipe.value = it
                    }
                }
            } else {
                _selectedRecipe.value = null
            }
        }

    init {
        // Initialize Firebase Service
        FirebaseService.initialize(application)
        isRealFirebaseEnabled = FirebaseService.isRealFirebaseEnabled

        val db = AppDatabase.getDatabase(application)
        repository = CookCanRepository(db)

        pantryItems = repository.getAllPantryItems()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        recipes = repository.getAllRecipes()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        shoppingItems = repository.getAllShoppingItems()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        mealPlanItems = repository.getAllMealPlans()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        chatHistory = repository.getChatHistory()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        // Insert mock/default pantry ingredients if database is empty on first boot for a rich experience
        viewModelScope.launch {
            pantryItems.take(1).collect { items ->
                if (items.isEmpty()) {
                    val defaults = listOf(
                        PantryItem(name = "Wild Salmon", quantity = 1.0, unit = "lb", category = "Meat", confidence = 0.98, freshness = "Fresh", purchaseDate = System.currentTimeMillis(), expirationDate = System.currentTimeMillis() + 3 * 24 * 3600 * 1000),
                        PantryItem(name = "Heirloom Tomato", quantity = 3.0, unit = "pcs", category = "Produce", confidence = 0.95, freshness = "Ripe", purchaseDate = System.currentTimeMillis(), expirationDate = System.currentTimeMillis() + 4 * 24 * 3600 * 1000),
                        PantryItem(name = "Fresh Garlic", quantity = 1.0, unit = "bulb", category = "Produce", confidence = 0.97, freshness = "Fresh", purchaseDate = System.currentTimeMillis(), expirationDate = System.currentTimeMillis() + 14 * 24 * 3600 * 1000),
                        PantryItem(name = "Rosemary", quantity = 2.0, unit = "sprigs", category = "Spices", confidence = 0.96, freshness = "Fresh", purchaseDate = System.currentTimeMillis(), expirationDate = System.currentTimeMillis() + 6 * 24 * 3600 * 1000),
                        PantryItem(name = "Sea Salt", quantity = 100.0, unit = "g", category = "Pantry", confidence = 0.99, freshness = "Fresh", purchaseDate = System.currentTimeMillis(), expirationDate = System.currentTimeMillis() + 300 * 24 * 3600 * 1000)
                    )
                    repository.pantryDao.insertItems(defaults)
                }
            }
        }
    }

    // Auth Actions
    fun login(email: String) {
        prefs.edit()
            .putBoolean("is_logged_in", true)
            .putString("user_email", email)
            .putString("user_uid", "local_sandbox_uid")
            .apply()
        userEmail = email
        userUid = "local_sandbox_uid"
        isLoggedIn = true
        authErrorMessage = null
    }

    fun signUpWithFirebase(email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            authErrorMessage = null
            try {
                when (val result = FirebaseService.signUpWithEmail(email, password)) {
                    is AuthResult.Success -> {
                        prefs.edit()
                            .putBoolean("is_logged_in", true)
                            .putString("user_email", result.email)
                            .putString("user_uid", result.uid)
                            .apply()
                        userEmail = result.email
                        userUid = result.uid
                        isLoggedIn = true
                        syncDataWithCloud() // Auto sync on registration
                    }
                    is AuthResult.Error -> {
                        authErrorMessage = result.message
                    }
                }
            } catch (e: Exception) {
                authErrorMessage = e.localizedMessage ?: "Sign up error"
            } finally {
                onSuccess()
            }
        }
    }

    fun signInWithFirebase(email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            authErrorMessage = null
            try {
                when (val result = FirebaseService.signInWithEmail(email, password)) {
                    is AuthResult.Success -> {
                        prefs.edit()
                            .putBoolean("is_logged_in", true)
                            .putString("user_email", result.email)
                            .putString("user_uid", result.uid)
                            .apply()
                        userEmail = result.email
                        userUid = result.uid
                        isLoggedIn = true
                        fetchAndMergeFromCloud() // Auto pull down their cloud data on login
                    }
                    is AuthResult.Error -> {
                        authErrorMessage = result.message
                    }
                }
            } catch (e: Exception) {
                authErrorMessage = e.localizedMessage ?: "Sign in error"
            } finally {
                onSuccess()
            }
        }
    }

    fun signInAnonymouslyWithFirebase(onSuccess: () -> Unit) {
        viewModelScope.launch {
            authErrorMessage = null
            try {
                when (val result = FirebaseService.signInAnonymously()) {
                    is AuthResult.Success -> {
                        prefs.edit()
                            .putBoolean("is_logged_in", true)
                            .putString("user_email", result.email)
                            .putString("user_uid", result.uid)
                            .apply()
                        userEmail = result.email
                        userUid = result.uid
                        isLoggedIn = true
                    }
                    is AuthResult.Error -> {
                        authErrorMessage = result.message
                    }
                }
            } catch (e: Exception) {
                authErrorMessage = e.localizedMessage ?: "Guest login error"
            } finally {
                onSuccess()
            }
        }
    }

    fun logout() {
        FirebaseService.signOut()
        prefs.edit()
            .putBoolean("is_logged_in", false)
            .putString("user_email", "")
            .putString("user_uid", "")
            .putLong("last_sync_timestamp", 0L)
            .apply()
        userEmail = ""
        userUid = ""
        isLoggedIn = false
        lastSyncTimestamp = 0L
        authErrorMessage = null
    }

    // CLOUD SYNC FUNCTIONS
    fun syncDataWithCloud() {
        if (userUid.isEmpty()) return
        viewModelScope.launch {
            isSyncInProgress = true
            try {
                val currentPantry = pantryItems.value
                val currentRecipes = recipes.value
                val currentShopping = shoppingItems.value

                val pantrySuccess = FirebaseService.syncPantryToCloud(userUid, currentPantry)
                val recipeSuccess = FirebaseService.syncRecipesToCloud(userUid, currentRecipes)
                val shoppingSuccess = FirebaseService.syncShoppingToCloud(userUid, currentShopping)

                if (pantrySuccess && recipeSuccess && shoppingSuccess) {
                    val now = System.currentTimeMillis()
                    prefs.edit().putLong("last_sync_timestamp", now).apply()
                    lastSyncTimestamp = now
                    Log.d("AppViewModel", "Cloud sync succeeded at $now")
                }
            } catch (e: Exception) {
                Log.e("AppViewModel", "Failed to sync to cloud: ${e.message}")
            } finally {
                isSyncInProgress = false
            }
        }
    }

    fun fetchAndMergeFromCloud() {
        if (userUid.isEmpty()) return
        viewModelScope.launch {
            isSyncInProgress = true
            try {
                val cloudPantry = FirebaseService.fetchPantryFromCloud(userUid)
                val cloudRecipes = FirebaseService.fetchRecipesFromCloud(userUid)
                val cloudShopping = FirebaseService.fetchShoppingFromCloud(userUid)

                if (cloudPantry.isNotEmpty()) {
                    repository.pantryDao.clearPantry()
                    repository.pantryDao.insertItems(cloudPantry)
                }
                if (cloudRecipes.isNotEmpty()) {
                    for (recipe in cloudRecipes) {
                        repository.recipeDao.insertRecipe(recipe)
                    }
                }
                if (cloudShopping.isNotEmpty()) {
                    repository.shoppingDao.clearChecked() // Just clear previous to prevent double duplicate checkout items
                    for (item in cloudShopping) {
                        repository.shoppingDao.insertItem(item)
                    }
                }

                val now = System.currentTimeMillis()
                prefs.edit().putLong("last_sync_timestamp", now).apply()
                lastSyncTimestamp = now
                Log.d("AppViewModel", "Cloud fetch & merge succeeded")
            } catch (e: Exception) {
                Log.e("AppViewModel", "Failed to fetch from cloud: ${e.message}")
            } finally {
                isSyncInProgress = false
            }
        }
    }

    // Pantry Actions
    fun addPantryItem(name: String, quantity: Double, unit: String, category: String, confidence: Double = 1.0) {
        viewModelScope.launch {
            repository.insertPantryItem(
                PantryItem(
                    name = name,
                    quantity = quantity,
                    unit = unit,
                    category = category,
                    confidence = confidence,
                    purchaseDate = System.currentTimeMillis(),
                    expirationDate = System.currentTimeMillis() + 7 * 24 * 3600 * 1000
                )
            )
        }
    }

    fun updatePantryItem(item: PantryItem) {
        viewModelScope.launch {
            repository.updatePantryItem(item)
        }
    }

    fun deletePantryItem(id: Int) {
        viewModelScope.launch {
            repository.deletePantryItem(id)
        }
    }

    // Shopping List Actions
    fun addShoppingItem(name: String, category: String, quantity: Double, unit: String) {
        viewModelScope.launch {
            repository.insertShoppingItem(
                ShoppingItem(
                    name = name,
                    category = category,
                    quantity = quantity,
                    unit = unit
                )
            )
        }
    }

    fun toggleShoppingItem(item: ShoppingItem) {
        viewModelScope.launch {
            repository.updateShoppingItem(item.copy(isChecked = !item.isChecked))
        }
    }

    fun deleteShoppingItem(id: Int) {
        viewModelScope.launch {
            repository.deleteShoppingItem(id)
        }
    }

    fun clearCheckedShopping() {
        viewModelScope.launch {
            repository.clearCheckedShoppingItems()
        }
    }

    // Meal Plan Actions
    fun addMealPlan(date: String, mealType: String, recipeName: String, calories: Int, protein: Int) {
        viewModelScope.launch {
            repository.insertMealPlan(
                MealPlanItem(
                    date = date,
                    mealType = mealType,
                    recipeName = recipeName,
                    calories = calories,
                    protein = protein
                )
            )
        }
    }

    fun deleteMealPlan(item: MealPlanItem) {
        viewModelScope.launch {
            repository.deleteMealPlan(item)
        }
    }

    // Chat Actions
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.insertChatMessage("user", text)
            isChatLoading = true
            errorMessage = null
            try {
                val response = repository.getAIChatResponse(chatHistory.value, text)
                repository.insertChatMessage("model", response)
            } catch (e: Exception) {
                errorMessage = e.message
                repository.insertChatMessage("model", "Apologies, Chef. I had trouble connecting to my recipe archives: ${e.message}")
            } finally {
                isChatLoading = false
            }
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearChatHistory()
        }
    }

    // Camera Scan Logic
    fun scanIngredients(bitmap: Bitmap) {
        viewModelScope.launch {
            isScanning = true
            errorMessage = null
            try {
                // Optimize bitmap and encode to Base64 using ImageAnalysisService
                val base64String = repository.imageAnalysisService.optimizeAndEncodeBitmap(bitmap)

                // Call Gemini for scan
                repository.scanIngredientsFromImage(base64String)
            } catch (e: Exception) {
                errorMessage = "Failed to scan photo: ${e.message}"
            } finally {
                isScanning = false
            }
        }
    }

    // Recipe Generation Flow
    fun generatePersonalizedRecipes(cuisine: String, mealType: String, maxTimeMinutes: Int, additionalPreferences: String = "") {
        viewModelScope.launch {
            isGeneratingRecipe = true
            errorMessage = null
            try {
                val items = pantryItems.value
                if (items.isEmpty()) {
                    throw Exception("Your pantry is empty! Scan ingredients or add them manually first.")
                }
                val results = repository.generateRecipes(cuisine, mealType, maxTimeMinutes, items, additionalPreferences)
                generatedRecipesState = results
            } catch (e: Exception) {
                errorMessage = e.message
            } finally {
                isGeneratingRecipe = false
            }
        }
    }

    fun toggleFavoriteRecipe(recipe: Recipe) {
        viewModelScope.launch {
            repository.updateRecipe(recipe.copy(isFavorite = !recipe.isFavorite))
        }
    }

    fun insertRecipe(recipe: Recipe) {
        viewModelScope.launch {
            repository.recipeDao.insertRecipe(recipe)
        }
    }

    fun updateCookingStep(recipe: Recipe, stepIndex: Int) {
        viewModelScope.launch {
            repository.updateRecipe(recipe.copy(inProgressStep = stepIndex))
        }
    }
}
