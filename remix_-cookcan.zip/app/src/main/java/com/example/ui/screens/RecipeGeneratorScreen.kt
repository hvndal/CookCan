package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.Recipe
import com.example.ui.AppViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

import com.example.ui.theme.bounceClick
import com.example.ui.theme.pulsate
import com.example.ui.theme.ConfettiEffect

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeGeneratorScreen(
    viewModel: AppViewModel,
    onNavigateToRecipe: (Int) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val recipeList by viewModel.recipes.collectAsState()
    val isGenerating = viewModel.isGeneratingRecipe
    val generatedRecipes = viewModel.generatedRecipesState

    // User preferences states
    var selectedCuisine by remember { mutableStateOf("Japanese") }
    var selectedMealType by remember { mutableStateOf("Snack") }
    var cookTimeMinutes by remember { mutableFloatStateOf(30f) }
    var additionalPreferences by remember { mutableStateOf("") }

    val dietaryOptions = listOf("Vegan", "Keto", "Gluten-Free", "Vegetarian", "Dairy-Free", "Low-Carb")
    var selectedDiets by remember { mutableStateOf(setOf<String>()) }
    var activeDietFilter by remember { mutableStateOf<String?>(null) }

    // Custom simulated Loading stage animation states
    var isThinkingLoading by remember { mutableStateOf(false) }
    var loadingPercentage by remember { mutableFloatStateOf(0f) }
    var loadingStatusText by remember { mutableStateOf("Analyzing ingredients...") }
    var showResultsState by remember { mutableStateOf(false) }
    var confettiTrigger by remember { mutableStateOf(false) }

    LaunchedEffect(showResultsState) {
        if (showResultsState) {
            confettiTrigger = true
            activeDietFilter = selectedDiets.firstOrNull()
        }
    }

    val cuisines = listOf("Italian", "Japanese", "Mediterranean", "French")

    Box(modifier = modifier.fillMaxSize()) {
        if (!isThinkingLoading && !showResultsState) {
            // Screen 1: Preferences input form
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Refine Choice", style = MaterialTheme.typography.headlineMedium) },
                        navigationIcon = {
                            IconButton(onClick = onNavigateBack) {
                                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                        }
                    )
                },
                modifier = Modifier.fillMaxSize()
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(MaterialTheme.colorScheme.background)
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(28.dp)) {
                        Column {
                            Text(
                                text = "Refine your choice",
                                style = MaterialTheme.typography.headlineLarge.copy(fontSize = 28.sp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Let's tailor the AI's suggestions to your mood.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Display error message if any
                        viewModel.errorMessage?.let { errorMsg ->
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Error,
                                        contentDescription = "Error",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = errorMsg,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                            }
                        }

                        // Cuisine selection list
                        Column {
                            Text(
                                text = "CUISINE STYLE",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                cuisines.forEach { cuisine ->
                                    val isSelected = selectedCuisine == cuisine
                                    Surface(
                                        onClick = { selectedCuisine = cuisine },
                                        shape = CircleShape,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerLow,
                                        border = if (isSelected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                        modifier = Modifier.padding(vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = cuisine,
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Meal type choice
                        Column {
                            Text(
                                text = "MEAL TYPE",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                // Dinner selection card
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(110.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .border(
                                            width = if (selectedMealType == "Dinner") 2.dp else 1.dp,
                                            color = if (selectedMealType == "Dinner") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                            shape = RoundedCornerShape(16.dp)
                                        )
                                        .clickable { selectedMealType = "Dinner" }
                                ) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(context)
                                            .data("https://lh3.googleusercontent.com/aida-public/AB6AXuACLDNg5PvAAflmCOA3xUC4K3vJ1qZkYduuNMuxUSUDIdJqYZvewEGY6d-yjyzVe7E1-JpZmhG00xr3s15PxO4glls4R7SSo42OBV5ScdY64skm5nwvzSp25UHBIUq-t9ke6Tmr8m9iz85dnl_rqPaAFSKK0sdxIV5jFezJJvJS3RJb1nLbMxy05-PgDNVdWh0Aq6NwS3-2wL2MpbHEA1PDOjOgMx1fLDiiaT3lzhuPki6de6eydvPX")
                                            .crossfade(true)
                                            .build(),
                                        contentDescription = "Dinner",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(Color.Black.copy(alpha = 0.4f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "Dinner",
                                            style = MaterialTheme.typography.headlineSmall.copy(color = Color.White)
                                        )
                                    }
                                }

                                // Snack selection card
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(110.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .border(
                                            width = if (selectedMealType == "Snack") 2.dp else 1.dp,
                                            color = if (selectedMealType == "Snack") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                            shape = RoundedCornerShape(16.dp)
                                        )
                                        .clickable { selectedMealType = "Snack" }
                                ) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(context)
                                            .data("https://lh3.googleusercontent.com/aida-public/AB6AXuAfI0odsyuICx6l-wFlm6-ZQWwBsvISIUgf6055AsPQgXQyo3VXDKf1ZnzILfwb6A7PawDm8b4hzio35O5rnSyAXFwLAiRFZXp2xyRPgsqmBK75Y2eB-xM3vXPEDJmiM8dSxrOrnD7xs3HUvlqBg5ag7RvcyaD81HLjwshRyQ6aW8j5r1HsU836SjUbIZ53Kt2FvlUk-an5JAKyiuGCES2DrZeiiA7tfgol9jdGQNAjCTUahBeLRYZN")
                                            .crossfade(true)
                                            .build(),
                                        contentDescription = "Snack",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                if (selectedMealType == "Snack") MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                                                else Color.Black.copy(alpha = 0.4f)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "Snack",
                                                style = MaterialTheme.typography.headlineSmall.copy(color = Color.White)
                                            )
                                            if (selectedMealType == "Snack") {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = "Selected",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Cooking time slider
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "COOKING TIME",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Text(
                                    text = "Max ${cookTimeMinutes.toInt()} mins",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Slider(
                                value = cookTimeMinutes,
                                onValueChange = { cookTimeMinutes = it },
                                valueRange = 15f..60f,
                                steps = 3,
                                colors = SliderDefaults.colors(
                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                    inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant,
                                    thumbColor = MaterialTheme.colorScheme.primary
                                )
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("15m", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline)
                                Text("30m", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline)
                                Text("45m", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline)
                                Text("60m+", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline)
                            }
                        }

                        // Dietary preferences selection
                        Column {
                            Text(
                                text = "DIETARY PREFERENCES",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                dietaryOptions.forEach { diet ->
                                    val isSelected = selectedDiets.contains(diet)
                                    Surface(
                                        shape = CircleShape,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerLow,
                                        border = if (isSelected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                        modifier = Modifier
                                            .padding(vertical = 4.dp)
                                            .bounceClick {
                                                selectedDiets = if (isSelected) {
                                                    selectedDiets - diet
                                                } else {
                                                    selectedDiets + diet
                                                }
                                            }
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                                        ) {
                                            if (isSelected) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = "Selected",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                            }
                                            Text(
                                                text = diet,
                                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Additional custom preferences text input
                        Column {
                            Text(
                                text = "ADDITIONAL SUGGESTIONS & PREFERENCES",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            OutlinedTextField(
                                value = additionalPreferences,
                                onValueChange = { additionalPreferences = it },
                                placeholder = { Text("e.g. make it spicy, gluten-free, use extra garlic...") },
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(40.dp))

                    // Sparkly Action Button
                    Button(
                        onClick = { },
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .pulsate()
                            .bounceClick {
                                coroutineScope.launch {
                                    isThinkingLoading = true
                                    loadingPercentage = 0.1f
                                    loadingStatusText = "Initiating AI chef..."

                                    val dietList = selectedDiets.toList()
                                    val combinedPrefs = buildString {
                                        if (dietList.isNotEmpty()) {
                                            append("Dietary restrictions/preferences: ${dietList.joinToString(", ")}. ")
                                        }
                                        if (additionalPreferences.isNotBlank()) {
                                            append(additionalPreferences)
                                        }
                                    }

                                    viewModel.generatePersonalizedRecipes(
                                        cuisine = selectedCuisine,
                                        mealType = selectedMealType,
                                        maxTimeMinutes = cookTimeMinutes.toInt(),
                                        additionalPreferences = combinedPrefs
                                    )

                                    // While it's generating, let's animate the loading stages smoothly
                                    var progress = 0.1f
                                    val statuses = listOf(
                                        "Analyzing pantry contents..." to 0.3f,
                                        "Consulting Michelin star databases..." to 0.5f,
                                        "Drafting personalized recipes..." to 0.7f,
                                        "Calculating nutritional profiles..." to 0.9f
                                    )
                                    var statusIndex = 0

                                    // Loop until the viewmodel finishes generating (it usually takes 4-10 seconds)
                                    while (viewModel.isGeneratingRecipe) {
                                        val (status, targetProgress) = statuses[statusIndex % statuses.size]
                                        loadingStatusText = status
                                        // Smoothly increment progress towards target
                                        while (progress < targetProgress && viewModel.isGeneratingRecipe) {
                                            progress += 0.05f
                                            loadingPercentage = progress
                                            delay(100)
                                        }
                                        delay(1000)
                                        statusIndex++
                                    }

                                    if (viewModel.errorMessage != null) {
                                        isThinkingLoading = false
                                        // Error will be displayed on the input form screen
                                    } else {
                                        loadingPercentage = 1.0f
                                        loadingStatusText = "Ready!"
                                        delay(500)
                                        isThinkingLoading = false
                                        showResultsState = true
                                    }
                                }
                            }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Generate Recipes",
                                style = MaterialTheme.typography.headlineSmall.copy(color = Color.White, fontSize = 20.sp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "Sparkle", tint = Color.White)
                        }
                    }
                }
            }
        } else if (isThinkingLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                GourmetThinkingLoader(
                    loadingPercentage = loadingPercentage,
                    statusText = loadingStatusText
                )
            }
        } else if (showResultsState) {
            // Screen 3: Curated results matching the gorgeous Cards mockup
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Curated for You", style = MaterialTheme.typography.headlineMedium) },
                        navigationIcon = {
                            IconButton(onClick = { showResultsState = false }) {
                                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                        }
                    )
                },
                modifier = Modifier.fillMaxSize()
            ) { innerPadding ->
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(MaterialTheme.colorScheme.background),
                    contentPadding = PaddingValues(24.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    item {
                        Column {
                            Text(
                                text = "Curated for You",
                                style = MaterialTheme.typography.headlineLarge.copy(fontSize = 30.sp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            val count = if (generatedRecipes.isNotEmpty()) generatedRecipes.size else 3
                            Text(
                                text = "$count gourmet matches found.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Real-time client-side dietary filter section
                    item {
                        Column {
                            Text(
                                text = "FILTER BY DIET",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val isAllSelected = activeDietFilter == null
                                Surface(
                                    shape = CircleShape,
                                    color = if (isAllSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerLow,
                                    border = if (isAllSelected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                    modifier = Modifier
                                        .padding(vertical = 4.dp)
                                        .bounceClick { activeDietFilter = null }
                                ) {
                                    Text(
                                        text = "All",
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                        color = if (isAllSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                                    )
                                }

                                dietaryOptions.forEach { diet ->
                                    val isSelected = activeDietFilter == diet
                                    Surface(
                                        shape = CircleShape,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerLow,
                                        border = if (isSelected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                        modifier = Modifier
                                            .padding(vertical = 4.dp)
                                            .bounceClick { activeDietFilter = diet }
                                    ) {
                                        Text(
                                            text = diet,
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (generatedRecipes.isNotEmpty()) {
                        val filteredRecipes = if (activeDietFilter == null) {
                            generatedRecipes
                        } else {
                            generatedRecipes.filter { recipe ->
                                recipe.name.contains(activeDietFilter!!, ignoreCase = true) ||
                                recipe.description.contains(activeDietFilter!!, ignoreCase = true) ||
                                recipe.tips.contains(activeDietFilter!!, ignoreCase = true) ||
                                recipe.ingredientsJson.contains(activeDietFilter!!, ignoreCase = true)
                            }
                        }

                        if (filteredRecipes.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No matching generated recipes found.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            }
                        } else {
                            items(filteredRecipes) { recipe ->
                                GeneratedRecipeCard(
                                    name = recipe.name,
                                    kcal = "${recipe.calories} kcal",
                                    tag = recipe.difficulty,
                                    time = "${recipe.prepTime + recipe.cookTime} mins",
                                    difficulty = recipe.difficulty,
                                    imageUrl = getRecipeImageUrl(recipe.name),
                                    onClick = {
                                        onNavigateToRecipe(recipe.id)
                                    }
                                )
                            }
                        }
                    } else {
                        val mockList = listOf(
                            Triple("Wild Salmon with Rosemary Infusion", "Keto Friendly", listOf("Keto", "Gluten-Free", "Dairy-Free", "Low-Carb")),
                            Triple("Zesty Ginger Garden Medley", "Vegan", listOf("Vegan", "Vegetarian", "Gluten-Free", "Dairy-Free", "Low-Carb")),
                            Triple("Honey Roasted Grape Crostini", "Vegetarian", listOf("Vegetarian"))
                        )

                        val filteredMocks = if (activeDietFilter == null) {
                            mockList
                        } else {
                            mockList.filter { it.third.contains(activeDietFilter) }
                        }

                        val showCard1 = filteredMocks.any { it.first == "Wild Salmon with Rosemary Infusion" }
                        val showCard2 = filteredMocks.any { it.first == "Zesty Ginger Garden Medley" }
                        val showCard3 = filteredMocks.any { it.first == "Honey Roasted Grape Crostini" }

                        if (filteredMocks.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No matching mock recipes found.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            }
                        }

                        if (showCard1) {
                            // Card 1
                            item {
                                GeneratedRecipeCard(
                                    name = "Wild Salmon with Rosemary Infusion",
                                    kcal = "320 kcal",
                                    tag = "Keto Friendly",
                                    time = "15 mins",
                                    difficulty = "Intermediate",
                                    imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuAhFQWEKWeVzczNzg35BsUxb4_CiO6a9-R29QyfwE9uJgiowhvSuX3t9EMoxOfc5HUAquTJz67NtT2xjKEjStOrC2O1BwK6eS8VOIH5Ij3J359lsONLSQ_lTapQshdSBx33BMAInOZl2DpllTVpBtgLNS9fqL_qBXt43h6OtX0DA1GHTQb1yLZcWcyemSEQChaxEdW6GxHTrkzTBUj0ZmDpAo6S5clbYyDqM4uAeJugCZ9RptiT0flH",
                                    onClick = {
                                        // Add mock database recipe object dynamically and open detail!
                                        val id = createAndSaveMockRecipe(viewModel, "Wild Salmon with Rosemary Infusion", 15, "Intermediate", 320, 28, 18, 5, "https://lh3.googleusercontent.com/aida-public/AB6AXuAhFQWEKWeVzczNzg35BsUxb4_CiO6a9-R29QyfwE9uJgiowhvSuX3t9EMoxOfc5HUAquTJz67NtT2xjKEjStOrC2O1BwK6eS8VOIH5Ij3J359lsONLSQ_lTapQshdSBx33BMAInOZl2DpllTVpBtgLNS9fqL_qBXt43h6OtX0DA1GHTQb1yLZcWcyemSEQChaxEdW6GxHTrkzTBUj0ZmDpAo6S5clbYyDqM4uAeJugCZ9RptiT0flH")
                                        onNavigateToRecipe(id)
                                    }
                                )
                            }
                        }

                        if (showCard2) {
                            // Card 2
                            item {
                                GeneratedRecipeCard(
                                    name = "Zesty Ginger Garden Medley",
                                    kcal = "240 kcal",
                                    tag = "Vegan",
                                    time = "20 mins",
                                    difficulty = "Easy",
                                    imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDlNxw88zX3NGycj_VDnEfXk0OK9khNk_BvrKF1Z5MSOOvf3t_GnLiMF8PFOyCs24cTzqc72U1OKIOktp7cZcFTLd0jqLtnk097RY4W0qpE16Qm-tr7Vl-0OqcQ0HCpKpnwAksr8AeqbcxLl1TyPN_VDCYWpplqHEjICxOgevxSzH125Eqpwardx3-90AxTkeFbaie3emxm4Pm0oglhJS1GjZD-XN12-Ct-QMVXbR58tvuHBSGfubrd",
                                    onClick = {
                                        val id = createAndSaveMockRecipe(viewModel, "Zesty Ginger Garden Medley", 20, "Easy", 240, 6, 8, 30, "https://lh3.googleusercontent.com/aida-public/AB6AXuDlNxw88zX3NGycj_VDnEfXk0OK9khNk_BvrKF1Z5MSOOvf3t_GnLiMF8PFOyCs24cTzqc72U1OKIOktp7cZcFTLd0jqLtnk097RY4W0qpE16Qm-tr7Vl-0OqcQ0HCpKpnwAksr8AeqbcxLl1TyPN_VDCYWpplqHEjICxOgevxSzH125Eqpwardx3-90AxTkeFbaie3emxm4Pm0oglhJS1GjZD-XN12-Ct-QMVXbR58tvuHBSGfubrd")
                                        onNavigateToRecipe(id)
                                    }
                                )
                            }
                        }

                        if (showCard3) {
                            // Card 3: Chef's Choice asymmetrical visual banner
                            item {
                                Surface(
                                    shape = RoundedCornerShape(24.dp),
                                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.25f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val id = createAndSaveMockRecipe(viewModel, "Honey Roasted Grape Crostini", 12, "Easy", 180, 4, 6, 25, "https://lh3.googleusercontent.com/aida-public/AB6AXuBE3AACsT96GH5A1QHamKSySW6TfuYobB6gsShOEET6UGGZqMsjtfy0I8Nq1MEcA7QRDef_sgz7_PaSgJdvfYNftoJKLMvaQypBT861a42zp9hEYocbLcmL5KSrm47WCsJJl6OCJbfoBob7w3EgJsT8T-jJEPkFR5JzH28l7Nn1eIlWq5I9jU7yDiAtSDjLXCbbZWhumb3xOeM2TKK253EhKQzCosMH6cfaKT5kzMv5D3LWfAUwkQhv")
                                            onNavigateToRecipe(id)
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.height(130.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(context)
                                                .data("https://lh3.googleusercontent.com/aida-public/AB6AXuBE3AACsT96GH5A1QHamKSySW6TfuYobB6gsShOEET6UGGZqMsjtfy0I8Nq1MEcA7QRDef_sgz7_PaSgJdvfYNftoJKLMvaQypBT861a42zp9hEYocbLcmL5KSrm47WCsJJl6OCJbfoBob7w3EgJsT8T-jJEPkFR5JzH28l7Nn1eIlWq5I9jU7yDiAtSDjLXCbbZWhumb3xOeM2TKK253EhKQzCosMH6cfaKT5kzMv5D3LWfAUwkQhv")
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = "Crostini",
                                            modifier = Modifier
                                                .fillMaxHeight()
                                                .width(110.dp)
                                                .clip(RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp)),
                                            contentScale = ContentScale.Crop
                                        )

                                        Column(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(16.dp),
                                            verticalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text(
                                                    text = "CHEF'S CHOICE",
                                                    style = MaterialTheme.typography.labelMedium.copy(
                                                        color = MaterialTheme.colorScheme.tertiary,
                                                        letterSpacing = 1.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 10.sp
                                                    )
                                                )
                                                Text(
                                                    text = "Honey Roasted Grape Crostini",
                                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = "A delicate balance of sweetness and artisanal crunch.",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "12m",
                                                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                                                )
                                                Icon(
                                                    imageVector = Icons.Default.ArrowForward,
                                                    contentDescription = "Proceed",
                                                    tint = MaterialTheme.colorScheme.tertiary,
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .background(Color.White, CircleShape)
                                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                                                        .padding(6.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        ConfettiEffect(
            trigger = confettiTrigger,
            onFinished = { confettiTrigger = false }
        )
    }
}

@Composable
fun GeneratedRecipeCard(
    name: String,
    kcal: String,
    tag: String,
    time: String,
    difficulty: String,
    imageUrl: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(imageUrl)
                        .crossfade(true)
                        .build(),
                    contentDescription = name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                Surface(
                    color = Color.White.copy(alpha = 0.9f),
                    shape = CircleShape,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = "Calories",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = kcal, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = name,
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = tag.uppercase(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Schedule, contentDescription = "Time", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = time, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Restaurant, contentDescription = "Difficulty", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = difficulty, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onClick,
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Savor this Recipe",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

// Helper to save a generated recipe and return its ID
fun createAndSaveMockRecipe(
    viewModel: AppViewModel,
    name: String,
    time: Int,
    diff: String,
    kcal: Int,
    p: Int,
    f: Int,
    c: Int,
    img: String
): Int {
    val recipeId = when (name) {
        "Wild Salmon with Rosemary Infusion" -> 101
        "Zesty Ginger Garden Medley" -> 102
        else -> 103
    }

    viewModel.insertRecipe(
        Recipe(
            id = recipeId,
            name = name,
            description = "An exquisite gourmet experience crafted by CookCan AI.",
            prepTime = 5,
            cookTime = time,
            difficulty = diff,
            calories = kcal,
            protein = p,
            fat = f,
            carbs = c,
            ingredientsJson = "[\"1 sheet pre-rolled puff pastry\",\"250g seasonal mixed vegetables\",\"100g soft goat cheese\",\"2 sprigs fresh rosemary, chopped\",\"1 egg (for wash)\"]",
            instructionsJson = "[\"Preheat your oven to 200°C (390°F). Roll out the puff pastry onto a parchment-lined baking sheet.\",\"Thinly slice your seasonal vegetables and toss them in olive oil, salt, and fresh chopped rosemary.\",\"Arrange the vegetables inside the pastry border. Dot with goat cheese, brush with egg wash and bake for 20-25 mins.\"]",
            tips = "Chill your pastry in the freezer for 5 minutes before baking to ensure maximum flakiness.",
            storageAdvice = "Keep in an airtight container for up to 2 days.",
            estimatedCost = 14.50,
            servings = 2,
            inProgressStep = -1
        )
    )

    return recipeId
}

fun getRecipeImageUrl(recipeName: String): String {
    return when {
        recipeName.contains("salmon", ignoreCase = true) -> "https://lh3.googleusercontent.com/aida-public/AB6AXuAhFQWEKWeVzczNzg35BsUxb4_CiO6a9-R29QyfwE9uJgiowhvSuX3t9EMoxOfc5HUAquTJz67NtT2xjKEjStOrC2O1BwK6eS8VOIH5Ij3J359lsONLSQ_lTapQshdSBx33BMAInOZl2DpllTVpBtgLNS9fqL_qBXt43h6OtX0DA1GHTQb1yLZcWcyemSEQChaxEdW6GxHTrkzTBUj0ZmDpAo6S5clbYyDqM4uAeJugCZ9RptiT0flH"
        recipeName.contains("grape", ignoreCase = true) || recipeName.contains("crostini", ignoreCase = true) -> "https://lh3.googleusercontent.com/aida-public/AB6AXuBE3AACsT96GH5A1QHamKSySW6TfuYobB6gsShOEET6UGGZqMsjtfy0I8Nq1MEcA7QRDef_sgz7_PaSgJdvfYNftoJKLMvaQypBT861a42zp9hEYocbLcmL5KSrm47WCsJJl6OCJbfoBob7w3EgJsT8T-jJEPkFR5JzH28l7Nn1eIlWq5I9jU7yDiAtSDjLXCbbZWhumb3xOeM2TKK253EhKQzCosMH6cfaKT5kzMv5D3LWfAUwkQhv"
        else -> "https://lh3.googleusercontent.com/aida-public/AB6AXuDlNxw88zX3NGycj_VDnEfXk0OK9khNk_BvrKF1Z5MSOOvf3t_GnLiMF8PFOyCs24cTzqc72U1OKIOktp7cZcFTLd0jqLtnk097RY4W0qpE16Qm-tr7Vl-0OqcQ0HCpKpnwAksr8AeqbcxLl1TyPN_VDCYWpplqHEjICxOgevxSzH125Eqpwardx3-90AxTkeFbaie3emxm4Pm0oglhJS1GjZD-XN12-Ct-QMVXbR58tvuHBSGfubrd"
    }
}

@Composable
fun GourmetThinkingLoader(
    loadingPercentage: Float,
    statusText: String
) {
    val infiniteTransition = rememberInfiniteTransition(label = "LoaderTransition")
    
    // Rotation of the outer dash ring
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "LoaderRotation"
    )

    // Pulsing core scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "LoaderPulse"
    )

    // Halo glow alpha
    val haloAlpha by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "LoaderHalo"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(32.dp)
    ) {
        Box(
            modifier = Modifier.size(200.dp),
            contentAlignment = Alignment.Center
        ) {
            // Pulse Halo 1
            Box(
                modifier = Modifier
                    .size(180.dp)
                    .scale(pulseScale)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = haloAlpha),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            // Pulse Halo 2 (asymmetrical offset)
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .scale(1.15f - (pulseScale - 0.95f))
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.tertiary.copy(alpha = haloAlpha * 0.7f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            // Canvas for orbiting particle & rotating dashed border
            val primaryColor = MaterialTheme.colorScheme.primary
            val tertiaryColor = MaterialTheme.colorScheme.tertiary
            Canvas(modifier = Modifier.size(160.dp)) {
                val centerOffset = Offset(size.width / 2, size.height / 2)
                val radius = size.width / 2 - 8.dp.toPx()

                // Draw rotating dashed background
                rotate(angle) {
                    drawCircle(
                        color = primaryColor.copy(alpha = 0.25f),
                        radius = radius,
                        style = Stroke(
                            width = 3.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(
                                floatArrayOf(20f, 20f),
                                0f
                            )
                        )
                    )
                    
                    // Draw outer orbit particle
                    drawCircle(
                        color = tertiaryColor,
                        radius = 8.dp.toPx(),
                        center = Offset(
                            x = centerOffset.x + radius * kotlin.math.cos(0f),
                            y = centerOffset.y + radius * kotlin.math.sin(0f)
                        )
                    )
                }
                
                // Static outer rings
                drawCircle(
                    color = primaryColor.copy(alpha = 0.08f),
                    radius = radius + 12.dp.toPx(),
                    style = Stroke(width = 1.dp.toPx())
                )
            }

            // Central Core
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.surface
                            )
                        )
                    )
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Thinking AI",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(44.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Beautiful animated headline
        val headlineTransition = rememberInfiniteTransition(label = "HeadlineAlpha")
        val textAlpha by headlineTransition.animateFloat(
            initialValue = 0.7f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1000, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "HeadlineAlphaValue"
        )

        Text(
            text = "Chef is Crafting...",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary.copy(alpha = textAlpha)
            )
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Curating a bespoke culinary experience from your scanned ingredients.",
            style = MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        Spacer(modifier = Modifier.height(40.dp))

        // Beautiful progress bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .height(10.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.CenterStart
        ) {
            // Background track pulse shimmer
            val shimmerTranslate by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 1000f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1500, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "ShimmerTranslate"
            )

            // Progress Fill
            Box(
                modifier = Modifier
                    .fillMaxWidth(loadingPercentage.coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.tertiary,
                                MaterialTheme.colorScheme.primary
                            ),
                            start = Offset(shimmerTranslate, 0f),
                            end = Offset(shimmerTranslate + 300f, 0f)
                        )
                    )
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Animated Ellipsis dots for loading status
        val dotFloat by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 3.9f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "DotFloat"
        )
        val dots = ".".repeat(dotFloat.toInt())

        Text(
            text = "$statusText$dots",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.outline
        )
    }
}
